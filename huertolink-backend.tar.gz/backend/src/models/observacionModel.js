const { query } = require('../config/database');

const BASE = `
  o.id_observacion, o.id_parcela, o.id_usuario, o.id_usuario_resuelve,
  o.tipo, o.titulo, o.descripcion, o.estado, o.prioridad,
  o.imagen_url, o.fecha_reporte, o.fecha_resolucion, o.notas_resolucion,
  p.codigo AS codigo_parcela, p.nombre AS nombre_parcela,
  CONCAT(ur.nombre,' ',ur.apellido) AS reportado_por,
  CONCAT(rs.nombre,' ',rs.apellido) AS resuelto_por
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${BASE} FROM observaciones o LEFT JOIN parcelas p ON o.id_parcela=p.id_parcela JOIN usuarios ur ON o.id_usuario=ur.id_usuario LEFT JOIN usuarios rs ON o.id_usuario_resuelve=rs.id_usuario WHERE 1=1`;
  const args = [];
  if (filters.tipo)       { sql += ' AND o.tipo = ?';       args.push(filters.tipo); }
  if (filters.estado)     { sql += ' AND o.estado = ?';     args.push(filters.estado); }
  if (filters.prioridad)  { sql += ' AND o.prioridad = ?';  args.push(filters.prioridad); }
  if (filters.id_parcela) { sql += ' AND o.id_parcela = ?'; args.push(filters.id_parcela); }
  sql += " ORDER BY FIELD(o.prioridad,'urgente','alta','media','baja'), o.fecha_reporte DESC";
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query(
    `SELECT ${BASE} FROM observaciones o LEFT JOIN parcelas p ON o.id_parcela=p.id_parcela JOIN usuarios ur ON o.id_usuario=ur.id_usuario LEFT JOIN usuarios rs ON o.id_usuario_resuelve=rs.id_usuario WHERE o.id_observacion = ?`,
    [id]
  );
  return r[0] || null;
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO observaciones (id_parcela, id_usuario, tipo, titulo, descripcion, estado, prioridad, imagen_url)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [d.id_parcela||null, d.id_usuario, d.tipo, d.titulo, d.descripcion, d.estado||'abierta', d.prioridad||'media', d.imagen_url||null]
  );
  return findById(r.insertId);
};

const update = async (id, d) => {
  const campos = ['id_parcela','tipo','titulo','descripcion','estado','prioridad','imagen_url','notas_resolucion'];
  const sets = []; const args = [];
  for (const c of campos) { if (d[c] !== undefined) { sets.push(`${c} = ?`); args.push(d[c]); } }
  if (d.id_usuario_resuelve && d.estado === 'resuelta') {
    sets.push('id_usuario_resuelve = ?', 'fecha_resolucion = NOW()');
    args.push(d.id_usuario_resuelve);
  }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE observaciones SET ${sets.join(', ')} WHERE id_observacion = ?`, args);
  return findById(id);
};

const remove = async (id) => {
  await query('DELETE FROM observaciones WHERE id_observacion = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, create, update, remove };
