const { query } = require('../config/database');

const findAll = async (filters = {}) => {
  let sql    = 'SELECT * FROM cultivos WHERE 1=1';
  const args = [];
  if (filters.activo !== undefined) { sql += ' AND activo = ?'; args.push(Number(filters.activo)); }
  sql += ' ORDER BY nombre_comun ASC';
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query('SELECT * FROM cultivos WHERE id_cultivo = ?', [id]);
  return r[0] || null;
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO cultivos (nombre_comun, nombre_cientifico, descripcion, frecuencia_riego_dias, dias_hasta_cosecha, unidad_medida, color_mapa, imagen_url)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [d.nombre_comun, d.nombre_cientifico||null, d.descripcion||null,
     d.frecuencia_riego_dias||2, d.dias_hasta_cosecha||60,
     d.unidad_medida||'kg', d.color_mapa||'#4CAF50', d.imagen_url||null]
  );
  return findById(r.insertId);
};

const update = async (id, d) => {
  const campos = ['nombre_comun','nombre_cientifico','descripcion','frecuencia_riego_dias','dias_hasta_cosecha','unidad_medida','color_mapa','imagen_url','activo'];
  const sets = []; const args = [];
  for (const c of campos) { if (d[c] !== undefined) { sets.push(`${c} = ?`); args.push(d[c]); } }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE cultivos SET ${sets.join(', ')} WHERE id_cultivo = ?`, args);
  return findById(id);
};

const remove = async (id) => {
  await query('UPDATE cultivos SET activo = 0 WHERE id_cultivo = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, create, update, remove };
