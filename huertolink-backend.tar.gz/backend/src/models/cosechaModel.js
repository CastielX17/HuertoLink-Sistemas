const { query } = require('../config/database');

const BASE = `
  co.id_cosecha, co.id_siembra, co.id_usuario, co.fecha_cosecha,
  co.cantidad_cosechada, co.unidad, co.distribucion_descripcion,
  co.es_distribuida, co.notas, co.creado_en,
  c.nombre_comun AS cultivo, c.color_mapa,
  p.codigo AS codigo_parcela, p.nombre AS nombre_parcela,
  CONCAT(u.nombre,' ',u.apellido) AS cosechador
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${BASE} FROM cosechas co JOIN siembras s ON co.id_siembra=s.id_siembra JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN parcelas p ON s.id_parcela=p.id_parcela JOIN usuarios u ON co.id_usuario=u.id_usuario WHERE 1=1`;
  const args = [];
  if (filters.id_usuario)      { sql += ' AND co.id_usuario = ?';   args.push(filters.id_usuario); }
  if (filters.es_distribuida !== undefined) { sql += ' AND co.es_distribuida = ?'; args.push(Number(filters.es_distribuida)); }
  if (filters.mes && filters.anio) {
    sql += ' AND YEAR(co.fecha_cosecha) = ? AND MONTH(co.fecha_cosecha) = ?';
    args.push(filters.anio, filters.mes);
  }
  sql += ' ORDER BY co.fecha_cosecha DESC';
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query(
    `SELECT ${BASE} FROM cosechas co JOIN siembras s ON co.id_siembra=s.id_siembra JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN parcelas p ON s.id_parcela=p.id_parcela JOIN usuarios u ON co.id_usuario=u.id_usuario WHERE co.id_cosecha = ?`,
    [id]
  );
  return r[0] || null;
};

const findDelMes = async () => {
  return query(
    `SELECT ${BASE} FROM cosechas co JOIN siembras s ON co.id_siembra=s.id_siembra JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN parcelas p ON s.id_parcela=p.id_parcela JOIN usuarios u ON co.id_usuario=u.id_usuario WHERE YEAR(co.fecha_cosecha)=YEAR(CURDATE()) AND MONTH(co.fecha_cosecha)=MONTH(CURDATE()) ORDER BY co.fecha_cosecha DESC`,
    []
  );
};

const resumenMes = async () => {
  return query(
    `SELECT YEAR(co.fecha_cosecha) AS anio, MONTH(co.fecha_cosecha) AS mes,
            c.nombre_comun AS cultivo, co.unidad,
            SUM(co.cantidad_cosechada) AS total,
            COUNT(*) AS num_cosechas,
            SUM(CASE WHEN co.es_distribuida=1 THEN co.cantidad_cosechada ELSE 0 END) AS distribuido
     FROM cosechas co
     JOIN siembras s ON co.id_siembra=s.id_siembra
     JOIN cultivos c ON s.id_cultivo=c.id_cultivo
     WHERE YEAR(co.fecha_cosecha)=YEAR(CURDATE()) AND MONTH(co.fecha_cosecha)=MONTH(CURDATE())
     GROUP BY anio, mes, cultivo, co.unidad
     ORDER BY total DESC`,
    []
  );
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO cosechas (id_siembra, id_usuario, fecha_cosecha, cantidad_cosechada, unidad, distribucion_descripcion, es_distribuida, notas)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [d.id_siembra, d.id_usuario, d.fecha_cosecha, d.cantidad_cosechada, d.unidad||'kg',
     d.distribucion_descripcion||null, d.es_distribuida?1:0, d.notas||null]
  );
  // Marcar siembra como cosechada si se indica
  if (d.marcar_cosechada) {
    await query("UPDATE siembras SET estado='cosechada' WHERE id_siembra = ?", [d.id_siembra]);
  }
  return findById(r.insertId);
};

const update = async (id, d) => {
  const campos = ['id_siembra','id_usuario','fecha_cosecha','cantidad_cosechada','unidad','distribucion_descripcion','es_distribuida','notas'];
  const sets = []; const args = [];
  for (const c of campos) { if (d[c] !== undefined) { sets.push(`${c} = ?`); args.push(d[c]); } }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE cosechas SET ${sets.join(', ')} WHERE id_cosecha = ?`, args);
  return findById(id);
};

const remove = async (id) => {
  await query('DELETE FROM cosechas WHERE id_cosecha = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, findDelMes, resumenMes, create, update, remove };
