const { query } = require('../config/database');

const BASE = `
  p.id_parcela, p.codigo, p.nombre, p.ubicacion_fila, p.ubicacion_columna,
  p.area_m2, p.estado, p.es_publica, p.descripcion,
  p.fecha_asignacion, p.creado_en, p.actualizado_en,
  u.id_usuario AS id_vecino, CONCAT(u.nombre,' ',u.apellido) AS nombre_vecino,
  u.telefono AS telefono_vecino
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${BASE} FROM parcelas p LEFT JOIN usuarios u ON p.id_usuario_asignado = u.id_usuario WHERE 1=1`;
  const args = [];
  if (filters.estado)     { sql += ' AND p.estado = ?';      args.push(filters.estado); }
  if (filters.es_publica !== undefined) { sql += ' AND p.es_publica = ?'; args.push(Number(filters.es_publica)); }
  sql += ' ORDER BY p.ubicacion_fila, p.ubicacion_columna';
  return query(sql, args);
};

const findById = async (id) => {
  const rows = await query(
    `SELECT ${BASE} FROM parcelas p LEFT JOIN usuarios u ON p.id_usuario_asignado = u.id_usuario WHERE p.id_parcela = ?`,
    [id]
  );
  return rows[0] || null;
};

// Devuelve la parcela con sus siembras activas (util para el mapa 2D)
const findByIdWithSiembras = async (id) => {
  const parcela = await findById(id);
  if (!parcela) return null;
  const siembras = await query(
    `SELECT s.id_siembra, s.estado, s.fecha_siembra, s.fecha_estimada_cosecha,
            s.cantidad_sembrada, s.unidad_cantidad, s.notas,
            c.nombre_comun, c.color_mapa, c.frecuencia_riego_dias,
            CONCAT(u.nombre,' ',u.apellido) AS sembrador
     FROM siembras s
     JOIN cultivos  c ON s.id_cultivo = c.id_cultivo
     JOIN usuarios  u ON s.id_usuario = u.id_usuario
     WHERE s.id_parcela = ? ORDER BY s.creado_en DESC`,
    [id]
  );
  return { ...parcela, siembras };
};

const create = async (data) => {
  const r = await query(
    `INSERT INTO parcelas (codigo, nombre, ubicacion_fila, ubicacion_columna, area_m2, estado, id_usuario_asignado, fecha_asignacion, es_publica, descripcion)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [data.codigo, data.nombre, data.ubicacion_fila, data.ubicacion_columna,
     data.area_m2 || 1.00, data.estado || 'disponible',
     data.id_usuario_asignado || null, data.fecha_asignacion || null,
     data.es_publica ? 1 : 0, data.descripcion || null]
  );
  return findById(r.insertId);
};

const update = async (id, data) => {
  const permitidos = ['codigo','nombre','ubicacion_fila','ubicacion_columna','area_m2','estado','id_usuario_asignado','fecha_asignacion','es_publica','descripcion'];
  const sets = []; const args = [];
  for (const c of permitidos) {
    if (data[c] !== undefined) { sets.push(`${c} = ?`); args.push(data[c]); }
  }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE parcelas SET ${sets.join(', ')} WHERE id_parcela = ?`, args);
  return findById(id);
};

const remove = async (id) => {
  await query('DELETE FROM parcelas WHERE id_parcela = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, findByIdWithSiembras, create, update, remove };
