const { query } = require('../config/database');

const BASE = `
  t.id_turno, t.id_parcela, t.id_usuario_asignado, t.fecha_turno,
  t.hora_inicio, t.hora_fin, t.estado, t.notas, t.creado_en,
  p.codigo AS codigo_parcela, p.nombre AS nombre_parcela,
  CONCAT(u.nombre,' ',u.apellido) AS responsable,
  u.telefono AS telefono_responsable,
  c.nombre_comun AS cultivo_sembrado, c.color_mapa,
  rr.id_registro, rr.fecha_hora_riego, rr.duracion_minutos,
  rr.cantidad_litros, rr.sincronizado
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${BASE} FROM turnos_riego t JOIN parcelas p ON t.id_parcela=p.id_parcela JOIN usuarios u ON t.id_usuario_asignado=u.id_usuario LEFT JOIN siembras s ON s.id_parcela=p.id_parcela AND s.estado='activa' LEFT JOIN cultivos c ON s.id_cultivo=c.id_cultivo LEFT JOIN registro_riego rr ON rr.id_turno=t.id_turno WHERE 1=1`;
  const args = [];
  if (filters.fecha)         { sql += ' AND t.fecha_turno = ?';         args.push(filters.fecha); }
  if (filters.estado)        { sql += ' AND t.estado = ?';              args.push(filters.estado); }
  if (filters.id_parcela)    { sql += ' AND t.id_parcela = ?';          args.push(filters.id_parcela); }
  if (filters.id_usuario)    { sql += ' AND t.id_usuario_asignado = ?'; args.push(filters.id_usuario); }
  if (filters.desde)         { sql += ' AND t.fecha_turno >= ?';        args.push(filters.desde); }
  if (filters.hasta)         { sql += ' AND t.fecha_turno <= ?';        args.push(filters.hasta); }
  sql += ' ORDER BY t.fecha_turno DESC, t.hora_inicio ASC';
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query(
    `SELECT ${BASE} FROM turnos_riego t JOIN parcelas p ON t.id_parcela=p.id_parcela JOIN usuarios u ON t.id_usuario_asignado=u.id_usuario LEFT JOIN siembras s ON s.id_parcela=p.id_parcela AND s.estado='activa' LEFT JOIN cultivos c ON s.id_cultivo=c.id_cultivo LEFT JOIN registro_riego rr ON rr.id_turno=t.id_turno WHERE t.id_turno = ?`,
    [id]
  );
  return r[0] || null;
};

const findHoy = async () => {
  return query(
    `SELECT ${BASE} FROM turnos_riego t JOIN parcelas p ON t.id_parcela=p.id_parcela JOIN usuarios u ON t.id_usuario_asignado=u.id_usuario LEFT JOIN siembras s ON s.id_parcela=p.id_parcela AND s.estado='activa' LEFT JOIN cultivos c ON s.id_cultivo=c.id_cultivo LEFT JOIN registro_riego rr ON rr.id_turno=t.id_turno WHERE t.fecha_turno = CURDATE() ORDER BY t.hora_inicio`,
    []
  );
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO turnos_riego (id_parcela, id_usuario_asignado, fecha_turno, hora_inicio, hora_fin, estado, notas)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [d.id_parcela, d.id_usuario_asignado, d.fecha_turno, d.hora_inicio||'08:00:00', d.hora_fin||'09:00:00', d.estado||'pendiente', d.notas||null]
  );
  return findById(r.insertId);
};

const update = async (id, d) => {
  const campos = ['id_parcela','id_usuario_asignado','fecha_turno','hora_inicio','hora_fin','estado','notas'];
  const sets = []; const args = [];
  for (const c of campos) { if (d[c] !== undefined) { sets.push(`${c} = ?`); args.push(d[c]); } }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE turnos_riego SET ${sets.join(', ')} WHERE id_turno = ?`, args);
  return findById(id);
};

const confirmarRiego = async (id_turno, d) => {
  await query(`UPDATE turnos_riego SET estado='completado' WHERE id_turno = ?`, [id_turno]);
  await query(
    `INSERT INTO registro_riego (id_turno, id_usuario, fecha_hora_riego, duracion_minutos, cantidad_litros, completado, sincronizado, notas)
     VALUES (?, ?, NOW(), ?, ?, 1, ?, ?)
     ON DUPLICATE KEY UPDATE duracion_minutos=VALUES(duracion_minutos), cantidad_litros=VALUES(cantidad_litros)`,
    [id_turno, d.id_usuario, d.duracion_minutos||null, d.cantidad_litros||null, d.sincronizado===false?0:1, d.notas||null]
  );
  return findById(id_turno);
};

const remove = async (id) => {
  await query('DELETE FROM turnos_riego WHERE id_turno = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, findHoy, create, update, confirmarRiego, remove };
