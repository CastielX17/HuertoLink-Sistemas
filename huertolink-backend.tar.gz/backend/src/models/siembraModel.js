const { query } = require('../config/database');

const BASE = `
  s.id_siembra, s.id_parcela, s.id_cultivo, s.id_usuario,
  s.fecha_siembra, s.fecha_estimada_cosecha, s.estado,
  s.cantidad_sembrada, s.unidad_cantidad, s.notas,
  s.creado_en, s.actualizado_en,
  p.codigo AS codigo_parcela, p.nombre AS nombre_parcela,
  c.nombre_comun AS cultivo, c.color_mapa, c.frecuencia_riego_dias,
  CONCAT(u.nombre,' ',u.apellido) AS sembrador
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${BASE} FROM siembras s JOIN parcelas p ON s.id_parcela=p.id_parcela JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN usuarios u ON s.id_usuario=u.id_usuario WHERE 1=1`;
  const args = [];
  if (filters.id_parcela) { sql += ' AND s.id_parcela = ?'; args.push(filters.id_parcela); }
  if (filters.estado)     { sql += ' AND s.estado = ?';     args.push(filters.estado); }
  if (filters.id_usuario) { sql += ' AND s.id_usuario = ?'; args.push(filters.id_usuario); }
  sql += ' ORDER BY s.fecha_siembra DESC';
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query(
    `SELECT ${BASE} FROM siembras s JOIN parcelas p ON s.id_parcela=p.id_parcela JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN usuarios u ON s.id_usuario=u.id_usuario WHERE s.id_siembra = ?`,
    [id]
  );
  return r[0] || null;
};

// Verifica si ya existe una siembra activa en la parcela (previene doble siembra)
const findActivaEnParcela = async (id_parcela) => {
  const r = await query(
    `SELECT s.id_siembra, c.nombre_comun, CONCAT(u.nombre,' ',u.apellido) AS sembrador
     FROM siembras s JOIN cultivos c ON s.id_cultivo=c.id_cultivo JOIN usuarios u ON s.id_usuario=u.id_usuario
     WHERE s.id_parcela = ? AND s.estado IN ('activa','en_preparacion')`,
    [id_parcela]
  );
  return r; // array; si length > 0 hay conflicto
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO siembras (id_parcela, id_cultivo, id_usuario, fecha_siembra, fecha_estimada_cosecha, estado, cantidad_sembrada, unidad_cantidad, notas)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [d.id_parcela, d.id_cultivo, d.id_usuario, d.fecha_siembra, d.fecha_estimada_cosecha,
     d.estado||'activa', d.cantidad_sembrada||1, d.unidad_cantidad||'plantas', d.notas||null]
  );
  return findById(r.insertId);
};

const update = async (id, d) => {
  const campos = ['id_parcela','id_cultivo','id_usuario','fecha_siembra','fecha_estimada_cosecha','estado','cantidad_sembrada','unidad_cantidad','notas'];
  const sets = []; const args = [];
  for (const c of campos) { if (d[c] !== undefined) { sets.push(`${c} = ?`); args.push(d[c]); } }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE siembras SET ${sets.join(', ')} WHERE id_siembra = ?`, args);
  return findById(id);
};

const remove = async (id) => {
  await query('DELETE FROM siembras WHERE id_siembra = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, findActivaEnParcela, create, update, remove };
