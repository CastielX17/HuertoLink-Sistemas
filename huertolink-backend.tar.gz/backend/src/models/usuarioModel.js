const { query } = require('../config/database');
const bcrypt    = require('bcrypt');

const CAMPOS = `
  u.id_usuario, u.nombre, u.apellido, u.email, u.telefono,
  u.id_rol, r.nombre AS nombre_rol, u.activo,
  u.puntos_reputacion, u.logro_titulo, u.avatar_url,
  u.fecha_registro, u.ultimo_acceso
`;

const findAll = async (filters = {}) => {
  let sql    = `SELECT ${CAMPOS} FROM usuarios u JOIN roles r ON u.id_rol = r.id_rol WHERE 1=1`;
  const args = [];

  if (filters.activo !== undefined) { sql += ' AND u.activo = ?';   args.push(Number(filters.activo)); }
  if (filters.id_rol)               { sql += ' AND u.id_rol = ?';   args.push(filters.id_rol); }
  if (filters.search) {
    sql += ' AND (u.nombre LIKE ? OR u.apellido LIKE ? OR u.email LIKE ?)';
    const t = `%${filters.search}%`;
    args.push(t, t, t);
  }

  sql += ' ORDER BY u.puntos_reputacion DESC, u.nombre ASC';
  return query(sql, args);
};

const findById = async (id) => {
  const rows = await query(
    `SELECT ${CAMPOS} FROM usuarios u JOIN roles r ON u.id_rol = r.id_rol WHERE u.id_usuario = ?`,
    [id]
  );
  return rows[0] || null;
};

const findByEmail = async (email) => {
  const rows = await query('SELECT * FROM usuarios WHERE email = ?', [email]);
  return rows[0] || null;
};

const create = async (data) => {
  const hash = await bcrypt.hash(data.password, parseInt(process.env.BCRYPT_ROUNDS) || 10);
  const result = await query(
    `INSERT INTO usuarios (nombre, apellido, email, password_hash, telefono, id_rol)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [data.nombre, data.apellido, data.email, hash, data.telefono || null, data.id_rol || 2]
  );
  return findById(result.insertId);
};

const update = async (id, data) => {
  const permitidos = ['nombre','apellido','email','telefono','id_rol','activo','puntos_reputacion','logro_titulo','avatar_url'];
  const sets = []; const args = [];
  for (const campo of permitidos) {
    if (data[campo] !== undefined) { sets.push(`${campo} = ?`); args.push(data[campo]); }
  }
  if (!sets.length) return findById(id);
  args.push(id);
  await query(`UPDATE usuarios SET ${sets.join(', ')} WHERE id_usuario = ?`, args);
  return findById(id);
};

const updatePassword = async (id, newPassword) => {
  const hash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 10);
  await query('UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?', [hash, id]);
};

const updateLastAccess = async (id) => {
  await query('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id_usuario = ?', [id]);
};

const addPoints = async (id, puntos) => {
  await query('UPDATE usuarios SET puntos_reputacion = puntos_reputacion + ? WHERE id_usuario = ?', [puntos, id]);
};

const remove = async (id) => {
  await query('UPDATE usuarios SET activo = 0 WHERE id_usuario = ?', [id]);
  return { deleted: true, id: Number(id) };
};

const verifyPassword = async (plain, hash) => bcrypt.compare(plain, hash);

module.exports = { findAll, findById, findByEmail, create, update, updatePassword, updateLastAccess, addPoints, remove, verifyPassword };
