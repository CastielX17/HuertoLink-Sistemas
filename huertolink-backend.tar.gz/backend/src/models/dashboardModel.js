const { query } = require('../config/database');

/** Parcelas con turno pendiente hoy y responsable */
const getTurnosHoy = async () => query(
  `SELECT t.id_turno, t.hora_inicio, t.hora_fin, t.estado, t.notas,
          p.id_parcela, p.codigo, p.nombre AS nombre_parcela, p.ubicacion_fila, p.ubicacion_columna,
          CONCAT(u.nombre,' ',u.apellido) AS responsable,
          u.id_usuario AS id_responsable, u.telefono,
          c.nombre_comun AS cultivo, c.color_mapa,
          s.fecha_estimada_cosecha,
          DATEDIFF(s.fecha_estimada_cosecha, CURDATE()) AS dias_para_cosecha
   FROM turnos_riego t
   JOIN parcelas p ON t.id_parcela=p.id_parcela
   JOIN usuarios u ON t.id_usuario_asignado=u.id_usuario
   LEFT JOIN siembras s ON s.id_parcela=p.id_parcela AND s.estado='activa'
   LEFT JOIN cultivos c ON s.id_cultivo=c.id_cultivo
   WHERE t.fecha_turno = CURDATE()
   ORDER BY t.estado, t.hora_inicio`, []
);

/** Ranking de vecinos por actividad */
const getRankingVecinos = async (limit = 10) => query(
  `SELECT u.id_usuario,
          CONCAT(u.nombre,' ',u.apellido) AS vecino,
          u.puntos_reputacion, u.logro_titulo, u.avatar_url,
          COUNT(DISTINCT CASE WHEN t.estado='completado' THEN t.id_turno END) AS riegos_completados,
          COUNT(DISTINCT CASE WHEN t.estado='omitido'    THEN t.id_turno END) AS riegos_omitidos,
          COUNT(DISTINCT co.id_cosecha) AS cosechas_realizadas,
          ROUND(
            COUNT(DISTINCT CASE WHEN t.estado='completado' THEN t.id_turno END)*100.0
            / NULLIF(COUNT(DISTINCT CASE WHEN t.estado IN ('completado','omitido') THEN t.id_turno END),0)
          ,1) AS pct_cumplimiento
   FROM usuarios u
   LEFT JOIN turnos_riego t ON u.id_usuario=t.id_usuario_asignado
   LEFT JOIN cosechas co ON u.id_usuario=co.id_usuario
   WHERE u.activo=1 AND u.id_rol IN (1,2)
   GROUP BY u.id_usuario
   ORDER BY u.puntos_reputacion DESC
   LIMIT ?`, [limit]
);

/** Resumen de cosechas del mes actual */
const getCosechasMes = async () => query(
  `SELECT c.nombre_comun AS cultivo, co.unidad,
          SUM(co.cantidad_cosechada) AS total,
          COUNT(*) AS num_cosechas,
          SUM(CASE WHEN co.es_distribuida=1 THEN co.cantidad_cosechada ELSE 0 END) AS distribuido
   FROM cosechas co
   JOIN siembras s ON co.id_siembra=s.id_siembra
   JOIN cultivos c ON s.id_cultivo=c.id_cultivo
   WHERE YEAR(co.fecha_cosecha)=YEAR(CURDATE()) AND MONTH(co.fecha_cosecha)=MONTH(CURDATE())
   GROUP BY c.nombre_comun, co.unidad
   ORDER BY total DESC`, []
);

/** Parcelas con siembra próxima a cosechar (<=7 dias) */
const getListasCosechar = async () => query(
  `SELECT p.id_parcela, p.codigo, p.nombre, c.nombre_comun AS cultivo, c.color_mapa,
          s.fecha_estimada_cosecha,
          DATEDIFF(s.fecha_estimada_cosecha, CURDATE()) AS dias_restantes,
          CONCAT(u.nombre,' ',u.apellido) AS responsable
   FROM siembras s
   JOIN parcelas p ON s.id_parcela=p.id_parcela
   JOIN cultivos c ON s.id_cultivo=c.id_cultivo
   JOIN usuarios u ON s.id_usuario=u.id_usuario
   WHERE s.estado='activa' AND s.fecha_estimada_cosecha <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
   ORDER BY s.fecha_estimada_cosecha`, []
);

/** Actividad reciente del sistema (ultimas 24h) */
const getActividadReciente = async (limit = 15) => query(
  `SELECT ha.id_actividad, ha.tipo_actividad, ha.descripcion,
          ha.entidad_tipo, ha.entidad_id, ha.fecha_hora,
          CONCAT(u.nombre,' ',u.apellido) AS usuario,
          u.logro_titulo
   FROM historial_actividades ha
   JOIN usuarios u ON ha.id_usuario=u.id_usuario
   WHERE ha.fecha_hora >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
   ORDER BY ha.fecha_hora DESC
   LIMIT ?`, [limit]
);

/** Resumen estadistico general */
const getStats = async () => {
  const [totales] = await query(
    `SELECT
       (SELECT COUNT(*) FROM usuarios WHERE activo=1 AND id_rol IN (1,2)) AS total_vecinos,
       (SELECT COUNT(*) FROM parcelas WHERE estado='ocupada') AS parcelas_ocupadas,
       (SELECT COUNT(*) FROM parcelas WHERE estado='disponible') AS parcelas_disponibles,
       (SELECT COUNT(*) FROM siembras WHERE estado='activa') AS siembras_activas,
       (SELECT COUNT(*) FROM turnos_riego WHERE fecha_turno=CURDATE() AND estado='pendiente') AS pendientes_hoy,
       (SELECT COUNT(*) FROM turnos_riego WHERE fecha_turno=CURDATE() AND estado='completado') AS completados_hoy,
       (SELECT COUNT(*) FROM turnos_riego WHERE fecha_turno=CURDATE() AND estado='omitido') AS omitidos_hoy,
       (SELECT COUNT(*) FROM observaciones WHERE estado IN ('abierta','en_proceso') AND prioridad IN ('urgente','alta')) AS alertas_activas`,
    []
  );
  return totales;
};

/** Vecinos sin actividad en los ultimos 15 dias (riesgo abandono) */
const getVecinosInactivos = async () => query(
  `SELECT u.id_usuario, CONCAT(u.nombre,' ',u.apellido) AS vecino,
          u.telefono, p.codigo, p.nombre AS nombre_parcela,
          MAX(ha.fecha_hora) AS ultima_actividad,
          DATEDIFF(NOW(), MAX(ha.fecha_hora)) AS dias_sin_actividad
   FROM usuarios u
   JOIN parcelas p ON p.id_usuario_asignado=u.id_usuario
   LEFT JOIN historial_actividades ha ON u.id_usuario=ha.id_usuario
   WHERE u.activo=1 AND u.id_rol=2
   GROUP BY u.id_usuario, p.id_parcela
   HAVING ultima_actividad IS NULL OR dias_sin_actividad >= 15
   ORDER BY dias_sin_actividad DESC`, []
);

module.exports = {
  getTurnosHoy, getRankingVecinos, getCosechasMes,
  getListasCosechar, getActividadReciente, getStats, getVecinosInactivos
};
