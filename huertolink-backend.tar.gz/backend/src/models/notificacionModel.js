const { query } = require('../config/database');

const findAll = async (filters = {}) => {
  let sql    = 'SELECT * FROM notificaciones WHERE 1=1';
  const args = [];
  if (filters.id_usuario) { sql += ' AND id_usuario = ?'; args.push(filters.id_usuario); }
  if (filters.leida !== undefined) { sql += ' AND leida = ?'; args.push(Number(filters.leida)); }
  if (filters.tipo)       { sql += ' AND tipo = ?';       args.push(filters.tipo); }
  sql += ' ORDER BY fecha_creacion DESC';
  if (filters.limit) { sql += ' LIMIT ?'; args.push(Number(filters.limit)); }
  return query(sql, args);
};

const findById = async (id) => {
  const r = await query('SELECT * FROM notificaciones WHERE id_notificacion = ?', [id]);
  return r[0] || null;
};

const countUnread = async (id_usuario) => {
  const r = await query('SELECT COUNT(*) AS total FROM notificaciones WHERE id_usuario = ? AND leida = 0', [id_usuario]);
  return r[0].total;
};

const create = async (d) => {
  const r = await query(
    `INSERT INTO notificaciones (id_usuario, tipo, titulo, mensaje, entidad_tipo, entidad_id)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [d.id_usuario, d.tipo, d.titulo, d.mensaje, d.entidad_tipo||null, d.entidad_id||null]
  );
  return findById(r.insertId);
};

const markAsRead = async (id) => {
  await query("UPDATE notificaciones SET leida=1, fecha_lectura=NOW() WHERE id_notificacion = ?", [id]);
  return findById(id);
};

const markAllAsRead = async (id_usuario) => {
  const r = await query(
    "UPDATE notificaciones SET leida=1, fecha_lectura=NOW() WHERE id_usuario = ? AND leida = 0",
    [id_usuario]
  );
  return { actualizadas: r.affectedRows };
};

const remove = async (id) => {
  await query('DELETE FROM notificaciones WHERE id_notificacion = ?', [id]);
  return { deleted: true, id: Number(id) };
};

module.exports = { findAll, findById, countUnread, create, markAsRead, markAllAsRead, remove };
