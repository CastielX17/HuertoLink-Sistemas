/**
 * Configuración central de la aplicación Express.
 * Registra: seguridad, CORS, logging, rutas y manejo de errores.
 */
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');

const routes             = require('./routes');
const { errorHandler }   = require('./middlewares/errorHandler');

const app = express();

// ── Seguridad ─────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin : process.env.FRONTEND_URL || 'http://localhost:5173',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// ── Logging ───────────────────────────────────────────────────
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Parseo de cuerpo ──────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Health check ──────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({
    success  : true,
    message  : '🌱 HuertoLink API funcionando correctamente',
    timestamp: new Date().toISOString(),
    version  : '1.0.0'
  });
});

// ── Rutas de la API ───────────────────────────────────────────
app.use('/api', routes);

// ── 404 ───────────────────────────────────────────────────────
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `Ruta ${req.method} ${req.originalUrl} no encontrada`
  });
});

// ── Manejo global de errores (debe ir al final) ───────────────
app.use(errorHandler);

module.exports = app;
