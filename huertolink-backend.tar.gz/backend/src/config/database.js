const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host            : process.env.DB_HOST     || 'localhost',
  port            : parseInt(process.env.DB_PORT) || 3306,
  user            : process.env.DB_USER     || 'root',
  password        : process.env.DB_PASSWORD || '',
  database        : process.env.DB_NAME     || 'huertolink',
  waitForConnections: true,
  connectionLimit   : 10,
  queueLimit        : 0,
  timezone          : '-04:00',
  charset           : 'utf8mb4',
  multipleStatements: false
});

const testConnection = async () => {
  const conn = await pool.getConnection();
  console.log('OK MySQL conectado');
  console.log('   BD: ' + (process.env.DB_NAME || 'huertolink'));
  conn.release();
};

const query = async (sql, params = []) => {
  try {
    const [rows] = await pool.execute(sql, params);
    return rows;
  } catch (err) {
    if (process.env.NODE_ENV === 'development') {
      console.error('SQL Error:', err.message, '|', sql.trim().slice(0, 150));
    }
    throw err;
  }
};

const transaction = async (callback) => {
  const conn = await pool.getConnection();
  await conn.beginTransaction();
  try {
    const result = await callback(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

module.exports = { pool, query, transaction, testConnection };
