const router   = require('express').Router();
const ctrl     = require('../controllers/notificacionesController');
const validate = require('../middlewares/validateRequest');
const { authenticate, authorize } = require('../middlewares/auth');
const { crearNotificacion } = require('../validators/notificacion.validator');

// Notificaciones del usuario autenticado
router.get   ('/mis',         authenticate,             ctrl.getMias);
router.put   ('/leer-todas',  authenticate,             ctrl.leerTodas);

// CRUD general (coordinadora)
router.get   ('/',            authenticate,             ctrl.getAll);
router.get   ('/:id',         authenticate,             ctrl.getById);
router.post  ('/',            authenticate, authorize(1), crearNotificacion, validate, ctrl.create);
router.put   ('/:id/leer',    authenticate,             ctrl.leer);
router.delete('/:id',         authenticate, authorize(1),                   ctrl.remove);

module.exports = router;
