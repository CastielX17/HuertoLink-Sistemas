const router   = require('express').Router();
const ctrl     = require('../controllers/usuariosController');
const validate = require('../middlewares/validateRequest');
const { authenticate, authorize } = require('../middlewares/auth');
const { crearUsuario, actualizarUsuario, login } = require('../validators/usuario.validator');

// Publicas
router.post('/login',        login,           validate, ctrl.login);

// Autenticadas
router.get  ('/me',          authenticate,             ctrl.getMe);
router.get  ('/',            authenticate,             ctrl.getAll);
router.get  ('/:id',         authenticate,             ctrl.getById);
router.post ('/',            authenticate, authorize(1), crearUsuario,      validate, ctrl.create);
router.put  ('/:id',         authenticate,             actualizarUsuario,  validate, ctrl.update);
router.delete('/:id',        authenticate, authorize(1),                             ctrl.remove);

module.exports = router;
