/**
 * Router raiz — registra todos los modulos de la API.
 * Prefijo base: /api
 */
const router = require('express').Router();

router.use('/auth',          require('./usuarios.routes'));     // login
router.use('/usuarios',      require('./usuarios.routes'));
router.use('/parcelas',      require('./parcelas.routes'));
router.use('/cultivos',      require('./cultivos.routes'));
router.use('/siembras',      require('./siembras.routes'));
router.use('/turnos',        require('./turnos.routes'));
router.use('/cosechas',      require('./cosechas.routes'));
router.use('/observaciones', require('./observaciones.routes'));
router.use('/notificaciones',require('./notificaciones.routes'));
router.use('/dashboard',     require('./dashboard.routes'));

// GET /api — listado de endpoints disponibles
router.get('/', (_req, res) => {
  res.json({
    success: true,
    message: 'HuertoLink API v1.0.0',
    endpoints: [
      'POST   /api/auth/login',
      'GET    /api/usuarios',
      'GET    /api/parcelas',
      'GET    /api/cultivos',
      'GET    /api/siembras',
      'GET    /api/turnos',
      'GET    /api/turnos/hoy',
      'POST   /api/turnos/:id/confirmar',
      'GET    /api/cosechas',
      'GET    /api/cosechas/mes',
      'GET    /api/observaciones',
      'GET    /api/notificaciones/mis',
      'GET    /api/dashboard',
      'GET    /api/dashboard/stats',
      'GET    /api/dashboard/turnos-hoy',
      'GET    /api/dashboard/ranking',
      'GET    /api/dashboard/cosechas'
    ]
  });
});

module.exports = router;
