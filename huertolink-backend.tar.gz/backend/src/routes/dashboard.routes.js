const router = require('express').Router();
const ctrl   = require('../controllers/dashboardController');
const { authenticate } = require('../middlewares/auth');

// GET /api/dashboard           — Resumen completo (todas las preguntas del caso)
router.get('/',          authenticate, ctrl.getDashboard);

// Endpoints individuales para carga progresiva del frontend
router.get('/stats',     authenticate, ctrl.getStats);
router.get('/turnos-hoy',authenticate, ctrl.getTurnosHoy);
router.get('/ranking',   authenticate, ctrl.getRankingVecinos);
router.get('/cosechas',  authenticate, ctrl.getCosechasMes);

module.exports = router;
