const router   = require('express').Router();
const ctrl     = require('../controllers/turnosController');
const validate = require('../middlewares/validateRequest');
const { authenticate, authorize } = require('../middlewares/auth');
const { crearTurno, actualizarTurno, confirmarRiego } = require('../validators/turno.validator');

// Ruta especial — debe ir antes de /:id
router.get ('hoy',              authenticate,             ctrl.getHoy);

router.get   ('/',              authenticate,             ctrl.getAll);
router.get   ('/:id',           authenticate,             ctrl.getById);
router.post  ('/',              authenticate, authorize(1), crearTurno,      validate, ctrl.create);
router.put   ('/:id',           authenticate, authorize(1), actualizarTurno, validate, ctrl.update);

// Acciones sobre un turno
router.post  ('/:id/confirmar', authenticate, confirmarRiego, validate, ctrl.confirmar);
router.put   ('/:id/omitir',    authenticate, authorize(1),             ctrl.omitir);

router.delete('/:id',           authenticate, authorize(1),             ctrl.remove);

module.exports = router;
