const router   = require('express').Router();
const ctrl     = require('../controllers/cosechasController');
const validate = require('../middlewares/validateRequest');
const { authenticate } = require('../middlewares/auth');
const { crearCosecha, actualizarCosecha } = require('../validators/cosecha.validator');

router.get ('mes',  authenticate, ctrl.getMes);   // antes de /:id
router.get ('/',    authenticate, ctrl.getAll);
router.get ('/:id', authenticate, ctrl.getById);
router.post ('/',   authenticate, crearCosecha,      validate, ctrl.create);
router.put  ('/:id',authenticate, actualizarCosecha, validate, ctrl.update);
router.delete('/:id',authenticate,                             ctrl.remove);

module.exports = router;
