const router   = require('express').Router();
const ctrl     = require('../controllers/parcelasController');
const validate = require('../middlewares/validateRequest');
const { authenticate, authorize } = require('../middlewares/auth');
const { crearParcela, actualizarParcela } = require('../validators/parcela.validator');

router.get   ('/',    authenticate,             ctrl.getAll);
router.get   ('/:id', authenticate,             ctrl.getById);
router.post  ('/',    authenticate, authorize(1), crearParcela,      validate, ctrl.create);
router.put   ('/:id', authenticate, authorize(1), actualizarParcela, validate, ctrl.update);
router.delete('/:id', authenticate, authorize(1),                              ctrl.remove);

module.exports = router;
