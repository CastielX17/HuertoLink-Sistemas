const router   = require('express').Router();
const ctrl     = require('../controllers/observacionesController');
const validate = require('../middlewares/validateRequest');
const { authenticate } = require('../middlewares/auth');
const { crearObservacion, actualizarObservacion } = require('../validators/observacion.validator');

router.get   ('/',    authenticate, ctrl.getAll);
router.get   ('/:id', authenticate, ctrl.getById);
router.post  ('/',    authenticate, crearObservacion,      validate, ctrl.create);
router.put   ('/:id', authenticate, actualizarObservacion, validate, ctrl.update);
router.delete('/:id', authenticate,                                  ctrl.remove);

module.exports = router;
