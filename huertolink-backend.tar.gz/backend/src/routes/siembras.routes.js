const router   = require('express').Router();
const ctrl     = require('../controllers/siembrasController');
const validate = require('../middlewares/validateRequest');
const { authenticate } = require('../middlewares/auth');
const { crearSiembra, actualizarSiembra } = require('../validators/siembra.validator');

router.get   ('/',    authenticate, ctrl.getAll);
router.get   ('/:id', authenticate, ctrl.getById);
router.post  ('/',    authenticate, crearSiembra,      validate, ctrl.create);
router.put   ('/:id', authenticate, actualizarSiembra, validate, ctrl.update);
router.delete('/:id', authenticate,                              ctrl.remove);

module.exports = router;
