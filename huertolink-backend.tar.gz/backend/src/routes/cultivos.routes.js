const router   = require('express').Router();
const ctrl     = require('../controllers/cultivosController');
const validate = require('../middlewares/validateRequest');
const { authenticate, authorize } = require('../middlewares/auth');
const { crearCultivo, actualizarCultivo } = require('../validators/cultivo.validator');

router.get   ('/',    authenticate,             ctrl.getAll);
router.get   ('/:id', authenticate,             ctrl.getById);
router.post  ('/',    authenticate, authorize(1), crearCultivo,      validate, ctrl.create);
router.put   ('/:id', authenticate, authorize(1), actualizarCultivo, validate, ctrl.update);
router.delete('/:id', authenticate, authorize(1),                              ctrl.remove);

module.exports = router;
