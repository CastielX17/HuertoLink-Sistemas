const { body } = require('express-validator');

const crearCultivo = [
  body('nombre_comun').trim().notEmpty().withMessage('El nombre común es requerido').isLength({ max:100 }),
  body('frecuencia_riego_dias').optional().isInt({ min:1, max:30 }).withMessage('Frecuencia de riego debe ser entre 1 y 30 días'),
  body('dias_hasta_cosecha').optional().isInt({ min:1, max:365 }),
  body('unidad_medida').optional().isIn(['kg','unidad','manojo','litros','gramos']),
  body('color_mapa').optional().matches(/^#[0-9A-Fa-f]{6}$/).withMessage('Color debe ser hexadecimal (#RRGGBB)')
];

const actualizarCultivo = [
  body('nombre_comun').optional().trim().isLength({ max:100 }),
  body('frecuencia_riego_dias').optional().isInt({ min:1, max:30 }),
  body('activo').optional().isBoolean()
];

module.exports = { crearCultivo, actualizarCultivo };
