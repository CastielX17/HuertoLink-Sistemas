const { body } = require('express-validator');
const ESTADOS  = ['en_preparacion','activa','cosechada','perdida'];

const crearSiembra = [
  body('id_parcela').isInt({ min:1 }).withMessage('id_parcela requerido'),
  body('id_cultivo').isInt({ min:1 }).withMessage('id_cultivo requerido'),
  body('fecha_siembra').isDate().withMessage('Fecha de siembra inválida (YYYY-MM-DD)'),
  body('fecha_estimada_cosecha').isDate().withMessage('Fecha estimada de cosecha inválida (YYYY-MM-DD)'),
  body('cantidad_sembrada').optional().isFloat({ min:0.1 }),
  body('estado').optional().isIn(ESTADOS)
];

const actualizarSiembra = [
  body('estado').optional().isIn(ESTADOS),
  body('fecha_estimada_cosecha').optional().isDate(),
  body('notas').optional().isString().isLength({ max:500 })
];

module.exports = { crearSiembra, actualizarSiembra };
