const { body } = require('express-validator');
const ESTADOS  = ['pendiente','completado','omitido','cancelado'];

const crearTurno = [
  body('id_parcela').isInt({ min:1 }).withMessage('id_parcela requerido'),
  body('id_usuario_asignado').isInt({ min:1 }).withMessage('id_usuario_asignado requerido'),
  body('fecha_turno').isDate().withMessage('Fecha de turno inválida (YYYY-MM-DD)'),
  body('hora_inicio').optional().matches(/^\d{2}:\d{2}(:\d{2})?$/).withMessage('Hora inicio inválida (HH:MM)'),
  body('hora_fin').optional().matches(/^\d{2}:\d{2}(:\d{2})?$/).withMessage('Hora fin inválida (HH:MM)'),
  body('estado').optional().isIn(ESTADOS)
];

const actualizarTurno = [
  body('estado').optional().isIn(ESTADOS),
  body('fecha_turno').optional().isDate(),
  body('notas').optional().isString().isLength({ max:500 })
];

const confirmarRiego = [
  body('duracion_minutos').optional().isInt({ min:1, max:300 }),
  body('cantidad_litros').optional().isFloat({ min:0.1 }),
  body('sincronizado').optional().isBoolean(),
  body('notas').optional().isString().isLength({ max:300 })
];

module.exports = { crearTurno, actualizarTurno, confirmarRiego };
