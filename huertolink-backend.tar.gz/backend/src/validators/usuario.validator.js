const { body } = require('express-validator');

const crearUsuario = [
  body('nombre').trim().notEmpty().withMessage('El nombre es requerido').isLength({ max:100 }),
  body('apellido').trim().notEmpty().withMessage('El apellido es requerido').isLength({ max:100 }),
  body('email').isEmail().withMessage('Debe ser un email válido').normalizeEmail(),
  body('password').isLength({ min:8 }).withMessage('La contraseña debe tener al menos 8 caracteres'),
  body('telefono').optional().matches(/^\+?[\d\s\-()]+$/).withMessage('Teléfono inválido'),
  body('id_rol').optional().isIn([1,2,3]).withMessage('Rol debe ser 1 (Coordinadora), 2 (Vecino) o 3 (Voluntario)')
];

const actualizarUsuario = [
  body('nombre').optional().trim().notEmpty().isLength({ max:100 }),
  body('apellido').optional().trim().notEmpty().isLength({ max:100 }),
  body('email').optional().isEmail().normalizeEmail(),
  body('telefono').optional().matches(/^\+?[\d\s\-()]+$/),
  body('id_rol').optional().isIn([1,2,3]),
  body('activo').optional().isBoolean(),
  body('puntos_reputacion').optional().isInt({ min:0 })
];

const login = [
  body('email').isEmail().withMessage('Email inválido').normalizeEmail(),
  body('password').notEmpty().withMessage('La contraseña es requerida')
];

module.exports = { crearUsuario, actualizarUsuario, login };
