const { body } = require('express-validator');
const TIPOS    = ['incidencia','vandalismo','plaga','mejora','consulta','conflicto'];
const ESTADOS  = ['abierta','en_proceso','resuelta','cerrada'];
const PRIOS    = ['baja','media','alta','urgente'];

const crearObservacion = [
  body('tipo').isIn(TIPOS).withMessage(`Tipo debe ser uno de: ${TIPOS.join(', ')}`),
  body('titulo').trim().notEmpty().isLength({ max:200 }),
  body('descripcion').trim().notEmpty().isLength({ max:2000 }),
  body('prioridad').optional().isIn(PRIOS),
  body('id_parcela').optional().isInt({ min:1 })
];

const actualizarObservacion = [
  body('estado').optional().isIn(ESTADOS),
  body('prioridad').optional().isIn(PRIOS),
  body('notas_resolucion').optional().isString().isLength({ max:500 })
];

module.exports = { crearObservacion, actualizarObservacion };
