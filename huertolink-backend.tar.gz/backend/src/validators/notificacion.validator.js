const { body } = require('express-validator');
const TIPOS    = ['riego','cosecha','conflicto','sistema','recordatorio','logro'];

const crearNotificacion = [
  body('id_usuario').isInt({ min:1 }).withMessage('id_usuario requerido'),
  body('tipo').isIn(TIPOS).withMessage(`Tipo debe ser uno de: ${TIPOS.join(', ')}`),
  body('titulo').trim().notEmpty().isLength({ max:200 }),
  body('mensaje').trim().notEmpty().isLength({ max:2000 }),
  body('entidad_tipo').optional().isString().isLength({ max:50 }),
  body('entidad_id').optional().isInt({ min:1 })
];

module.exports = { crearNotificacion };
