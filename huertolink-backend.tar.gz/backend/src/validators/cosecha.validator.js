const { body } = require('express-validator');

const crearCosecha = [
  body('id_siembra').isInt({ min:1 }).withMessage('id_siembra requerido'),
  body('fecha_cosecha').isDate().withMessage('Fecha de cosecha inválida (YYYY-MM-DD)'),
  body('cantidad_cosechada').isFloat({ min:0.01 }).withMessage('Cantidad cosechada debe ser mayor a 0'),
  body('unidad').optional().isIn(['kg','unidad','manojo','litros','gramos']),
  body('es_distribuida').optional().isBoolean(),
  body('marcar_cosechada').optional().isBoolean()
];

const actualizarCosecha = [
  body('cantidad_cosechada').optional().isFloat({ min:0.01 }),
  body('es_distribuida').optional().isBoolean(),
  body('distribucion_descripcion').optional().isString().isLength({ max:500 })
];

module.exports = { crearCosecha, actualizarCosecha };
