const { body } = require('express-validator');
const ESTADOS  = ['disponible','ocupada','mantenimiento','abandonada','regalo'];

const crearParcela = [
  body('codigo').trim().notEmpty().withMessage('El código es requerido').isLength({ max:20 }),
  body('nombre').trim().notEmpty().withMessage('El nombre es requerido').isLength({ max:100 }),
  body('ubicacion_fila').isInt({ min:1 }).withMessage('Fila debe ser número entero positivo'),
  body('ubicacion_columna').isInt({ min:1 }).withMessage('Columna debe ser número entero positivo'),
  body('area_m2').optional().isFloat({ min:0.1 }).withMessage('Área debe ser mayor a 0'),
  body('estado').optional().isIn(ESTADOS).withMessage(`Estado debe ser uno de: ${ESTADOS.join(', ')}`),
  body('id_usuario_asignado').optional().isInt({ min:1 }),
  body('es_publica').optional().isBoolean()
];

const actualizarParcela = [
  body('codigo').optional().trim().isLength({ max:20 }),
  body('nombre').optional().trim().isLength({ max:100 }),
  body('estado').optional().isIn(ESTADOS),
  body('area_m2').optional().isFloat({ min:0.1 }),
  body('es_publica').optional().isBoolean()
];

module.exports = { crearParcela, actualizarParcela };
