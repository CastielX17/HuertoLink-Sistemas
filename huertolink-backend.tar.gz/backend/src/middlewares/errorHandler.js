/**
 * AppError — Error operacional con codigo HTTP.
 * Se distingue de errores de programacion para darle el tratamiento adecuado.
 */
class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.statusCode    = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * errorHandler — Middleware global de manejo de errores.
 * Debe registrarse DESPUES de todas las rutas en app.js.
 */
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message    = err.message    || 'Error interno del servidor';

  // MySQL: registro duplicado (UNIQUE constraint)
  if (err.code === 'ER_DUP_ENTRY') {
    statusCode = 409;
    message    = 'Ya existe un registro con esos datos. Verifica email u otro campo unico.';
  }

  // MySQL: FK en uso — no se puede eliminar
  if (err.code === 'ER_ROW_IS_REFERENCED_2') {
    statusCode = 409;
    message    = 'No se puede eliminar: el registro esta siendo referenciado por otros datos.';
  }

  // MySQL: FK inexistente — referencia a ID que no existe
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    statusCode = 400;
    message    = 'El ID referenciado no existe en la tabla relacionada.';
  }

  // JWT invalido
  if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    message    = 'Token invalido. Inicia sesion nuevamente.';
  }

  // JWT expirado
  if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    message    = 'Token expirado. Inicia sesion nuevamente.';
  }

  // Log completo solo en desarrollo
  if (process.env.NODE_ENV === 'development') {
    console.error('[ERROR]', err.stack);
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && {
      stack : err.stack,
      codigo: err.code
    })
  });
};

module.exports = { errorHandler, AppError };
