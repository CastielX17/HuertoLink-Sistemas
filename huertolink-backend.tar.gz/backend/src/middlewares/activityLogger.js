const { query } = require('../config/database');

/**
 * logActivity — Registra cualquier accion del sistema en historial_actividades.
 * No interrumpe el flujo principal si falla (catch silencioso + console.error).
 *
 * @param {object} opts
 * @param {number} opts.id_usuario
 * @param {string} opts.tipo_actividad  Ej: 'riego_completado', 'siembra', 'cosecha'
 * @param {string} opts.descripcion
 * @param {string} [opts.entidad_tipo]  Ej: 'turno_riego', 'parcela', 'cosecha'
 * @param {number} [opts.entidad_id]
 * @param {object} [opts.metadata]      Datos JSON adicionales
 */
const logActivity = async ({
  id_usuario,
  tipo_actividad,
  descripcion,
  entidad_tipo = null,
  entidad_id   = null,
  metadata     = null
}) => {
  try {
    await query(
      `INSERT INTO historial_actividades
         (id_usuario, tipo_actividad, descripcion, entidad_tipo, entidad_id, metadata)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        id_usuario,
        tipo_actividad,
        descripcion,
        entidad_tipo,
        entidad_id,
        metadata ? JSON.stringify(metadata) : null
      ]
    );
  } catch (err) {
    console.error('[ActivityLogger] Error al registrar actividad:', err.message);
  }
};

module.exports = { logActivity };
