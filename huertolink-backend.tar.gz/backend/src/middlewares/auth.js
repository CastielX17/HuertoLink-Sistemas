const jwt          = require('jsonwebtoken');
const { AppError } = require('./errorHandler');
const { query }    = require('../config/database');

/**
 * authenticate — Verifica el token JWT del header Authorization.
 * Adjunta el usuario decodificado a req.user para uso posterior.
 */
const authenticate = async (req, res, next) => {
  try {
    const auth = req.headers.authorization;
    if (!auth || !auth.startsWith('Bearer ')) {
      return next(new AppError('Token de autenticacion requerido', 401));
    }

    const token   = auth.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const rows = await query(
      `SELECT id_usuario, nombre, apellido, email, id_rol, activo
       FROM usuarios WHERE id_usuario = ? AND activo = 1`,
      [decoded.id]
    );

    if (!rows[0]) {
      return next(new AppError('Usuario no encontrado o inactivo', 401));
    }

    req.user = rows[0];
    next();
  } catch (err) {
    next(err);
  }
};

/**
 * authorize — Restringe el acceso segun el nivel de rol.
 *   1 = Coordinadora (admin)
 *   2 = Vecino Colaborador
 *   3 = Voluntario Ocasional
 *
 * Uso: router.delete('/:id', authenticate, authorize(1), controller.remove)
 */
const authorize = (...niveles) => (req, res, next) => {
  if (!niveles.includes(req.user.id_rol)) {
    return next(new AppError('No tienes permisos para realizar esta accion', 403));
  }
  next();
};

module.exports = { authenticate, authorize };
