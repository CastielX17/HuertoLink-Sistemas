const { validationResult } = require('express-validator');

/**
 * validateRequest — Procesa los resultados de express-validator.
 * Debe colocarse DESPUES de los validadores en la cadena de middlewares.
 * Devuelve 422 con detalle de errores de forma homogenea.
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: 'Error de validacion en los datos enviados.',
      errors : errors.array().map(e => ({
        campo  : e.path,
        mensaje: e.msg,
        valor  : e.value
      }))
    });
  }

  next();
};

module.exports = validateRequest;
