const Model        = require('../models/turnoModel');
const UsuarioModel = require('../models/usuarioModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};

const getHoy = async (req, res, next) => {
  try {
    const d = await Model.findHoy();
    res.json({ success:true, fecha: new Date().toISOString().split('T')[0], count:d.length, data:d });
  } catch(e){ next(e); }
};

const getById = async (req, res, next) => {
  try {
    const d = await Model.findById(req.params.id);
    if (!d) return next(new AppError('Turno no encontrado', 404));
    ok(res, d);
  } catch(e){ next(e); }
};

const create = async (req, res, next) => {
  try {
    const data = await Model.create(req.body);
    ok(res, data, 'Turno de riego creado correctamente', 201);
  } catch(e){ next(e); }
};

const update = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Turno no encontrado', 404));
    const data = await Model.update(req.params.id, req.body);
    ok(res, data, 'Turno actualizado correctamente');
  } catch(e){ next(e); }
};

/** POST /api/turnos/:id/confirmar — Confirma el riego y cierra el turno */
const confirmar = async (req, res, next) => {
  try {
    const turno = await Model.findById(req.params.id);
    if (!turno) return next(new AppError('Turno no encontrado', 404));
    if (turno.estado === 'completado') return next(new AppError('El turno ya fue confirmado anteriormente', 409));
    if (turno.estado === 'cancelado')  return next(new AppError('No se puede confirmar un turno cancelado', 400));

    const data = await Model.confirmarRiego(req.params.id, {
      id_usuario      : req.user.id_usuario,
      duracion_minutos: req.body.duracion_minutos,
      cantidad_litros : req.body.cantidad_litros,
      sincronizado    : req.body.sincronizado,
      notas           : req.body.notas
    });

    // Sumar puntos al vecino que completó el riego
    await UsuarioModel.addPoints(req.user.id_usuario, 10);

    await logActivity({
      id_usuario   : req.user.id_usuario,
      tipo_actividad: 'riego_completado',
      descripcion   : `Riego confirmado en parcela ${turno.codigo_parcela}`,
      entidad_tipo  : 'turno_riego',
      entidad_id    : turno.id_turno,
      metadata      : { parcela: turno.codigo_parcela, litros: req.body.cantidad_litros }
    });
    ok(res, data, 'Riego confirmado correctamente. +10 puntos de reputación');
  } catch(e){ next(e); }
};

/** PUT /api/turnos/:id/omitir — Marca turno como omitido */
const omitir = async (req, res, next) => {
  try {
    const turno = await Model.findById(req.params.id);
    if (!turno) return next(new AppError('Turno no encontrado', 404));
    const data = await Model.update(req.params.id, { estado: 'omitido', notas: req.body.notas || 'Turno marcado como omitido' });
    await logActivity({
      id_usuario   : req.user.id_usuario,
      tipo_actividad: 'riego_omitido',
      descripcion   : `Turno omitido en parcela ${turno.codigo_parcela} — responsable: ${turno.responsable}`,
      entidad_tipo  : 'turno_riego',
      entidad_id    : turno.id_turno,
      metadata      : { responsable_id: turno.id_usuario_asignado, parcela: turno.codigo_parcela }
    });
    ok(res, data, 'Turno marcado como omitido');
  } catch(e){ next(e); }
};

const remove = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Turno no encontrado', 404));
    const data = await Model.remove(req.params.id);
    ok(res, data, 'Turno eliminado correctamente');
  } catch(e){ next(e); }
};

module.exports = { getAll, getHoy, getById, create, update, confirmar, omitir, remove };
