const Model        = require('../models/parcelaModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll = async (req, res, next) => {
  try {
    const data = await Model.findAll(req.query);
    res.json({ success: true, count: data.length, data });
  } catch (e) { next(e); }
};

const getById = async (req, res, next) => {
  try {
    const data = await Model.findByIdWithSiembras(req.params.id);
    if (!data) return next(new AppError('Parcela no encontrada', 404));
    ok(res, data);
  } catch (e) { next(e); }
};

const create = async (req, res, next) => {
  try {
    const data = await Model.create(req.body);
    await logActivity({ id_usuario: req.user.id_usuario, tipo_actividad: 'gestion_parcela', descripcion: `Parcela ${data.codigo} creada`, entidad_tipo: 'parcela', entidad_id: data.id_parcela });
    ok(res, data, 'Parcela creada correctamente', 201);
  } catch (e) { next(e); }
};

const update = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Parcela no encontrada', 404));
    const data = await Model.update(req.params.id, req.body);
    await logActivity({ id_usuario: req.user.id_usuario, tipo_actividad: 'gestion_parcela', descripcion: `Parcela ${data.codigo} actualizada — estado: ${data.estado}`, entidad_tipo: 'parcela', entidad_id: data.id_parcela, metadata: { estado_anterior: existe.estado, estado_nuevo: data.estado } });
    ok(res, data, 'Parcela actualizada correctamente');
  } catch (e) { next(e); }
};

const remove = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Parcela no encontrada', 404));
    const data = await Model.remove(req.params.id);
    ok(res, data, 'Parcela eliminada correctamente');
  } catch (e) { next(e); }
};

module.exports = { getAll, getById, create, update, remove };
