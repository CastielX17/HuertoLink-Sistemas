const Model        = require('../models/siembraModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};

const getById = async (req, res, next) => {
  try {
    const d = await Model.findById(req.params.id);
    if (!d) return next(new AppError('Siembra no encontrada', 404));
    ok(res, d);
  } catch(e){ next(e); }
};

const create = async (req, res, next) => {
  try {
    // REGLA DE NEGOCIO: Verificar que no haya siembra activa en la misma parcela
    const activas = await Model.findActivaEnParcela(req.body.id_parcela);
    if (activas.length > 0) {
      return next(new AppError(
        `La parcela ya tiene ${activas.length} siembra(s) activa(s): ${activas.map(s => s.nombre_comun).join(', ')}. Finaliza la siembra anterior antes de iniciar una nueva.`,
        409
      ));
    }

    const data = await Model.create({ ...req.body, id_usuario: req.body.id_usuario || req.user.id_usuario });
    await logActivity({
      id_usuario   : req.user.id_usuario,
      tipo_actividad: 'siembra',
      descripcion   : `Siembra de ${data.cultivo} registrada en ${data.codigo_parcela}`,
      entidad_tipo  : 'siembra',
      entidad_id    : data.id_siembra,
      metadata      : { cultivo: data.cultivo, parcela: data.codigo_parcela, cantidad: data.cantidad_sembrada }
    });
    ok(res, data, 'Siembra registrada correctamente', 201);
  } catch(e){ next(e); }
};

const update = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Siembra no encontrada', 404));
    const data = await Model.update(req.params.id, req.body);
    ok(res, data, 'Siembra actualizada correctamente');
  } catch(e){ next(e); }
};

const remove = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Siembra no encontrada', 404));
    const data = await Model.remove(req.params.id);
    ok(res, data, 'Siembra eliminada correctamente');
  } catch(e){ next(e); }
};

module.exports = { getAll, getById, create, update, remove };
