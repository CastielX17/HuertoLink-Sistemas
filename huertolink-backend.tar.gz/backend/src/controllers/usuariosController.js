const jwt          = require('jsonwebtoken');
const Model        = require('../models/usuarioModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll = async (req, res, next) => {
  try {
    const data = await Model.findAll(req.query);
    res.json({ success: true, count: data.length, data });
  } catch (e) { next(e); }
};

const getById = async (req, res, next) => {
  try {
    const data = await Model.findById(req.params.id);
    if (!data) return next(new AppError('Usuario no encontrado', 404));
    ok(res, data);
  } catch (e) { next(e); }
};

const create = async (req, res, next) => {
  try {
    const existe = await Model.findByEmail(req.body.email);
    if (existe) return next(new AppError('Ya existe una cuenta con ese email', 409));
    const data = await Model.create(req.body);
    await logActivity({ id_usuario: req.user?.id_usuario || data.id_usuario, tipo_actividad: 'registro', descripcion: `Nuevo vecino registrado: ${data.nombre} ${data.apellido}`, entidad_tipo: 'usuario', entidad_id: data.id_usuario });
    ok(res, data, 'Usuario creado correctamente', 201);
  } catch (e) { next(e); }
};

const update = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Usuario no encontrado', 404));
    const data = await Model.update(req.params.id, req.body);
    ok(res, data, 'Usuario actualizado correctamente');
  } catch (e) { next(e); }
};

const remove = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id);
    if (!existe) return next(new AppError('Usuario no encontrado', 404));
    if (existe.id_rol === 1) return next(new AppError('No se puede desactivar al Coordinador', 400));
    const data = await Model.remove(req.params.id);
    ok(res, data, 'Usuario desactivado correctamente');
  } catch (e) { next(e); }
};

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const usuario = await Model.findByEmail(email);
    if (!usuario) return next(new AppError('Credenciales incorrectas', 401));
    if (!usuario.activo) return next(new AppError('Cuenta desactivada. Contacta a la coordinadora.', 403));

    const valid = await Model.verifyPassword(password, usuario.password_hash);
    if (!valid) return next(new AppError('Credenciales incorrectas', 401));

    await Model.updateLastAccess(usuario.id_usuario);
    await logActivity({ id_usuario: usuario.id_usuario, tipo_actividad: 'login', descripcion: `${usuario.nombre} ${usuario.apellido} inició sesión` });

    const token = jwt.sign(
      { id: usuario.id_usuario, rol: usuario.id_rol },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    const { password_hash, ...perfil } = usuario;
    ok(res, { token, usuario: perfil }, 'Login exitoso');
  } catch (e) { next(e); }
};

const getMe = async (req, res, next) => {
  try {
    const data = await Model.findById(req.user.id_usuario);
    ok(res, data);
  } catch (e) { next(e); }
};

module.exports = { getAll, getById, create, update, remove, login, getMe };
