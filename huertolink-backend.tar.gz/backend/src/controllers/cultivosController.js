const Model        = require('../models/cultivoModel');
const { AppError } = require('../middlewares/errorHandler');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll  = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};
const getById = async (req, res, next) => {
  try { const d = await Model.findById(req.params.id); if(!d) return next(new AppError('Cultivo no encontrado',404)); ok(res,d); } catch(e){ next(e); }
};
const create  = async (req, res, next) => {
  try { const d = await Model.create(req.body); ok(res,d,'Cultivo creado',201); } catch(e){ next(e); }
};
const update  = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Cultivo no encontrado',404));
    const d = await Model.update(req.params.id, req.body); ok(res,d,'Cultivo actualizado');
  } catch(e){ next(e); }
};
const remove  = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Cultivo no encontrado',404));
    const d = await Model.remove(req.params.id); ok(res,d,'Cultivo desactivado');
  } catch(e){ next(e); }
};

module.exports = { getAll, getById, create, update, remove };
