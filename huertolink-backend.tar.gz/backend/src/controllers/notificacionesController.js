const Model        = require('../models/notificacionModel');
const { AppError } = require('../middlewares/errorHandler');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getMias = async (req, res, next) => {
  try {
    const filters = { id_usuario: req.user.id_usuario, ...req.query };
    const data    = await Model.findAll(filters);
    const noLeidas= await Model.countUnread(req.user.id_usuario);
    res.json({ success:true, count:data.length, no_leidas:noLeidas, data });
  } catch(e){ next(e); }
};
const getAll  = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};
const getById = async (req, res, next) => {
  try { const d = await Model.findById(req.params.id); if(!d) return next(new AppError('Notificación no encontrada',404)); ok(res,d); } catch(e){ next(e); }
};
const create  = async (req, res, next) => {
  try { const d = await Model.create(req.body); ok(res,d,'Notificación creada',201); } catch(e){ next(e); }
};
const leer    = async (req, res, next) => {
  try {
    const d = await Model.findById(req.params.id); if(!d) return next(new AppError('Notificación no encontrada',404));
    const r = await Model.markAsRead(req.params.id); ok(res,r,'Notificación marcada como leída');
  } catch(e){ next(e); }
};
const leerTodas = async (req, res, next) => {
  try { const d = await Model.markAllAsRead(req.user.id_usuario); ok(res,d,'Todas las notificaciones marcadas como leídas'); } catch(e){ next(e); }
};
const remove  = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Notificación no encontrada',404));
    const d = await Model.remove(req.params.id); ok(res,d,'Notificación eliminada');
  } catch(e){ next(e); }
};

module.exports = { getMias, getAll, getById, create, leer, leerTodas, remove };
