const Model        = require('../models/cosechaModel');
const UsuarioModel = require('../models/usuarioModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll    = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};
const getById   = async (req, res, next) => {
  try { const d = await Model.findById(req.params.id); if(!d) return next(new AppError('Cosecha no encontrada',404)); ok(res,d); } catch(e){ next(e); }
};
const getMes    = async (req, res, next) => {
  try {
    const cosechas = await Model.findDelMes();
    const resumen  = await Model.resumenMes();
    res.json({ success:true, count:cosechas.length, resumen, data:cosechas });
  } catch(e){ next(e); }
};
const create    = async (req, res, next) => {
  try {
    const data = await Model.create({ ...req.body, id_usuario: req.body.id_usuario || req.user.id_usuario });
    await UsuarioModel.addPoints(req.user.id_usuario, 20);
    await logActivity({
      id_usuario: req.user.id_usuario, tipo_actividad:'cosecha',
      descripcion:`Cosecha registrada: ${data.cantidad_cosechada} ${data.unidad} de ${data.cultivo} en ${data.codigo_parcela}`,
      entidad_tipo:'cosecha', entidad_id:data.id_cosecha,
      metadata:{ cultivo:data.cultivo, cantidad:data.cantidad_cosechada, unidad:data.unidad }
    });
    ok(res,data,'Cosecha registrada correctamente. +20 puntos de reputación',201);
  } catch(e){ next(e); }
};
const update    = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Cosecha no encontrada',404));
    const d = await Model.update(req.params.id,req.body); ok(res,d,'Cosecha actualizada');
  } catch(e){ next(e); }
};
const remove    = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Cosecha no encontrada',404));
    const d = await Model.remove(req.params.id); ok(res,d,'Cosecha eliminada');
  } catch(e){ next(e); }
};

module.exports = { getAll, getById, getMes, create, update, remove };
