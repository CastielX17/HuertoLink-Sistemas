const DashModel = require('../models/dashboardModel');

const getDashboard = async (req, res, next) => {
  try {
    const [stats, turnosHoy, cosechasMes, rankingVecinos, listasParaCosechar, actividadReciente, vecinosInactivos] = await Promise.all([
      DashModel.getStats(),
      DashModel.getTurnosHoy(),
      DashModel.getCosechasMes(),
      DashModel.getRankingVecinos(10),
      DashModel.getListasCosechar(),
      DashModel.getActividadReciente(15),
      DashModel.getVecinosInactivos()
    ]);

    res.json({
      success: true,
      data: {
        fecha        : new Date().toISOString().split('T')[0],
        estadisticas : stats,
        turnos_hoy   : {
          pendientes : turnosHoy.filter(t => t.estado === 'pendiente'),
          completados: turnosHoy.filter(t => t.estado === 'completado'),
          omitidos   : turnosHoy.filter(t => t.estado === 'omitido')
        },
        cosechas_mes        : cosechasMes,
        ranking_vecinos     : rankingVecinos,
        listas_para_cosechar: listasParaCosechar,
        actividad_reciente  : actividadReciente,
        alertas             : {
          vecinos_inactivos: vecinosInactivos,
          total_alertas    : stats.alertas_activas
        }
      }
    });
  } catch(e){ next(e); }
};

const getTurnosHoy       = async (req, res, next) => {
  try { const d = await DashModel.getTurnosHoy();       res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};
const getRankingVecinos  = async (req, res, next) => {
  try { const d = await DashModel.getRankingVecinos(req.query.limit||10); res.json({ success:true, data:d }); } catch(e){ next(e); }
};
const getCosechasMes     = async (req, res, next) => {
  try { const d = await DashModel.getCosechasMes();     res.json({ success:true, data:d }); } catch(e){ next(e); }
};
const getStats           = async (req, res, next) => {
  try { const d = await DashModel.getStats();           res.json({ success:true, data:d }); } catch(e){ next(e); }
};

module.exports = { getDashboard, getTurnosHoy, getRankingVecinos, getCosechasMes, getStats };
