const Model        = require('../models/observacionModel');
const NotifModel   = require('../models/notificacionModel');
const { AppError } = require('../middlewares/errorHandler');
const { logActivity } = require('../middlewares/activityLogger');
const { query }    = require('../config/database');

const ok = (res, data, msg = 'OK', status = 200) =>
  res.status(status).json({ success: true, message: msg, data });

const getAll    = async (req, res, next) => {
  try { const d = await Model.findAll(req.query); res.json({ success:true, count:d.length, data:d }); } catch(e){ next(e); }
};
const getById   = async (req, res, next) => {
  try { const d = await Model.findById(req.params.id); if(!d) return next(new AppError('Observación no encontrada',404)); ok(res,d); } catch(e){ next(e); }
};
const create = async (req, res, next) => {
  try {
    const data = await Model.create({ ...req.body, id_usuario: req.body.id_usuario || req.user.id_usuario });
    // Notificar a la coordinadora si es urgente o vandalismo
    if (['urgente','alta'].includes(data.prioridad) || data.tipo === 'vandalismo') {
      const coords = await query("SELECT id_usuario FROM usuarios WHERE id_rol=1 AND activo=1", []);
      for (const c of coords) {
        await NotifModel.create({
          id_usuario: c.id_usuario, tipo:'conflicto',
          titulo:`Nueva observación ${data.prioridad}: ${data.titulo}`,
          mensaje: data.descripcion.slice(0, 300),
          entidad_tipo:'observacion', entidad_id:data.id_observacion
        });
      }
    }
    await logActivity({ id_usuario:req.user.id_usuario, tipo_actividad:'observacion', descripcion:`Observación reportada: ${data.titulo}`, entidad_tipo:'observacion', entidad_id:data.id_observacion });
    ok(res,data,'Observación reportada correctamente',201);
  } catch(e){ next(e); }
};
const update    = async (req, res, next) => {
  try {
    const existe = await Model.findById(req.params.id); if(!existe) return next(new AppError('Observación no encontrada',404));
    const body = req.body.estado === 'resuelta' ? { ...req.body, id_usuario_resuelve: req.user.id_usuario } : req.body;
    const data = await Model.update(req.params.id, body); ok(res,data,'Observación actualizada');
  } catch(e){ next(e); }
};
const remove    = async (req, res, next) => {
  try {
    const e = await Model.findById(req.params.id); if(!e) return next(new AppError('Observación no encontrada',404));
    const d = await Model.remove(req.params.id); ok(res,d,'Observación eliminada');
  } catch(e){ next(e); }
};

module.exports = { getAll, getById, create, update, remove };
