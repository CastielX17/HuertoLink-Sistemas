/**
 * HuertoLink Backend — Punto de entrada del servidor
 * Carga variables de entorno, verifica conexión a DB y levanta Express.
 */
require('dotenv').config();
const app = require('./src/app');
const { testConnection } = require('./src/config/database');

const PORT = process.env.PORT || 3001;

const startServer = async () => {
  try {
    await testConnection();
    app.listen(PORT, () => {
      console.log(`\n🌱 HuertoLink Backend activo`);
      console.log(`📡 URL    : http://localhost:${PORT}`);
      console.log(`🏥 Health : http://localhost:${PORT}/health`);
      console.log(`📚 API    : http://localhost:${PORT}/api`);
      console.log(`🔧 Entorno: ${process.env.NODE_ENV || 'development'}\n`);
    });
  } catch (error) {
    console.error('❌ Error fatal al iniciar el servidor:', error.message);
    process.exit(1);
  }
};

// Manejo global de excepciones no capturadas
process.on('uncaughtException', (err) => {
  console.error('❌ Excepción no capturada:', err.message);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ Promesa rechazada sin manejo:', reason);
  process.exit(1);
});

startServer();
