# HuertoLink — Frontend

Aplicación React (Vite) para la gestión de huertos urbanos comunitarios.
Construida según la Guía de Estándares UX/UI: accesibilidad para adultos
mayores, alto contraste, botones grandes (48dp+), navegación lineal sin
gestos complejos y feedback visual inmediato.

## Instalación

```bash
npm install
cp .env.example .env     # editar VITE_API_URL si el backend no está en localhost:3001
npm run dev               # http://localhost:5173
```

## Credenciales de prueba (dataset del backend)

| Rol          | Email                        | Password      |
|--------------|-------------------------------|---------------|
| Coordinadora | carmen.rojas@huertolink.cl   | Huerto2026!   |
| Vecino       | juan.perez@huertolink.cl     | Huerto2026!   |

## Estructura

```
src/
  api/          Servicios Axios (uno por recurso del backend)
  components/
    common/     Button, Card, Input, Modal, Toast… (design system)
    layout/     AppShell, BottomNav, TopBar, ProtectedRoute
    dashboard/  Tarjetas específicas del Dashboard
    parcelas/   Mapa 2D y tarjeta de parcela
    turnos/     Lista y modal de confirmación de riego
  context/      AuthContext (sesión) + ToastContext (feedback)
  hooks/        useFetch, useDebounce
  pages/        Una pantalla = un archivo
  routes/       AppRoutes.jsx (mapa de navegación)
  styles/       tokens.css (design tokens) + global.css
  utils/        constants.js + formatters.js
```

## Build de producción

```bash
npm run build      # genera /dist
npm run preview    # sirve /dist localmente para probar
```
