/**
 * axiosClient — Instancia central de Axios.
 * - Inyecta el JWT automáticamente en cada petición.
 * - Captura 401 y fuerza logout (token expirado/inválido).
 * - Normaliza errores para que los componentes solo manejen `error.message`.
 */
import axios from 'axios';

const axiosClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
  timeout: 15000
});

axiosClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('huertolink_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

axiosClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const status  = error.response?.status;
    const message = error.response?.data?.message || 'Error de conexión con el servidor';

    if (status === 401) {
      localStorage.removeItem('huertolink_token');
      localStorage.removeItem('huertolink_user');
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    }

    return Promise.reject({
      status,
      message,
      errors: error.response?.data?.errors || []
    });
  }
);

export default axiosClient;
