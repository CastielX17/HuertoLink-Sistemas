import client from './axiosClient';

export const getDashboard      = () => client.get('/dashboard');
export const getDashboardStats = () => client.get('/dashboard/stats');
export const getRankingVecinos = () => client.get('/dashboard/ranking');
