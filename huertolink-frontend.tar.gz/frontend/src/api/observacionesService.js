import client from './axiosClient';

export const getObservaciones   = (params = {}) => client.get('/observaciones', { params });
export const getObservacion     = (id)          => client.get(`/observaciones/${id}`);
export const crearObservacion   = (data)        => client.post('/observaciones', data);
export const actualizarObservacion = (id, data) => client.put(`/observaciones/${id}`, data);
export const eliminarObservacion   = (id)       => client.delete(`/observaciones/${id}`);
