import client from './axiosClient';

export const getUsuarios   = (params = {}) => client.get('/usuarios', { params });
export const getUsuario    = (id)          => client.get(`/usuarios/${id}`);
export const crearUsuario  = (data)        => client.post('/usuarios', data);
export const actualizarUsuario = (id, data)=> client.put(`/usuarios/${id}`, data);
export const eliminarUsuario   = (id)      => client.delete(`/usuarios/${id}`);
