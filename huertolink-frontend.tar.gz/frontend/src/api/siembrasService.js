import client from './axiosClient';

export const getSiembras   = (params = {}) => client.get('/siembras', { params });
export const getSiembra    = (id)          => client.get(`/siembras/${id}`);
export const crearSiembra  = (data)        => client.post('/siembras', data);
export const actualizarSiembra = (id, data)=> client.put(`/siembras/${id}`, data);
export const eliminarSiembra   = (id)      => client.delete(`/siembras/${id}`);
