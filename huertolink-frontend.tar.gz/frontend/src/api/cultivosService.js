import client from './axiosClient';

export const getCultivos   = (params = {}) => client.get('/cultivos', { params });
export const getCultivo    = (id)          => client.get(`/cultivos/${id}`);
export const crearCultivo  = (data)        => client.post('/cultivos', data);
export const actualizarCultivo = (id, data)=> client.put(`/cultivos/${id}`, data);
export const eliminarCultivo   = (id)      => client.delete(`/cultivos/${id}`);
