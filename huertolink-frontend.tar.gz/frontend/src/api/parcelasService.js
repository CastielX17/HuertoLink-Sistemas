import client from './axiosClient';

export const getParcelas   = (params = {}) => client.get('/parcelas', { params });
export const getParcela    = (id)          => client.get(`/parcelas/${id}`);
export const crearParcela  = (data)        => client.post('/parcelas', data);
export const actualizarParcela = (id, data)=> client.put(`/parcelas/${id}`, data);
export const eliminarParcela   = (id)      => client.delete(`/parcelas/${id}`);
