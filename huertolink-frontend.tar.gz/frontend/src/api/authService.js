import client from './axiosClient';

export const login = (email, password) =>
  client.post('/auth/login', { email, password });

export const getMe = () => client.get('/usuarios/me');
