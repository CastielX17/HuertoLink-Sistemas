import client from './axiosClient';

export const getCosechas     = (params = {}) => client.get('/cosechas', { params });
export const getCosechasMes  = ()             => client.get('/cosechas/mes');
export const getCosecha      = (id)           => client.get(`/cosechas/${id}`);
export const crearCosecha    = (data)         => client.post('/cosechas', data);
export const actualizarCosecha = (id, data)   => client.put(`/cosechas/${id}`, data);
export const eliminarCosecha = (id)           => client.delete(`/cosechas/${id}`);
