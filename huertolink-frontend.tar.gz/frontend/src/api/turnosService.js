import client from './axiosClient';

export const getTurnos       = (params = {}) => client.get('/turnos', { params });
export const getTurnosHoy    = ()             => client.get('/turnos/hoy');
export const getTurno        = (id)           => client.get(`/turnos/${id}`);
export const crearTurno      = (data)         => client.post('/turnos', data);
export const actualizarTurno = (id, data)     => client.put(`/turnos/${id}`, data);
export const confirmarRiego  = (id, data = {})=> client.post(`/turnos/${id}/confirmar`, data);
export const omitirTurno     = (id, notas)    => client.put(`/turnos/${id}/omitir`, { notas });
export const eliminarTurno   = (id)           => client.delete(`/turnos/${id}`);
