import client from './axiosClient';

export const getMisNotificaciones = (params = {}) => client.get('/notificaciones/mis', { params });
export const marcarLeida          = (id)           => client.put(`/notificaciones/${id}/leer`);
export const marcarTodasLeidas    = ()              => client.put('/notificaciones/leer-todas');
export const eliminarNotificacion = (id)           => client.delete(`/notificaciones/${id}`);
