import { Routes, Route } from 'react-router-dom';

import ProtectedRoute from '../components/layout/ProtectedRoute';

import Login           from '../pages/auth/Login';
import Dashboard       from '../pages/Dashboard';
import Turnos          from '../pages/Turnos';
import Parcelas        from '../pages/Parcelas';
import ParcelaDetalle  from '../pages/ParcelaDetalle';
import Cultivos        from '../pages/Cultivos';
import NuevaSiembra    from '../pages/NuevaSiembra';
import Cosechas        from '../pages/Cosechas';
import NuevaCosecha    from '../pages/NuevaCosecha';
import Historial       from '../pages/Historial';
import Notificaciones  from '../pages/Notificaciones';
import Perfil          from '../pages/Perfil';
import Coordinacion    from '../pages/Coordinacion';
import NotFound        from '../pages/NotFound';

/**
 * AppRoutes — Mapa de navegación de HuertoLink.
 * Navegación lineal: cada ruta es una pantalla completa, sin
 * rutas anidadas complejas (estándar UX "paso a paso").
 */
export default function AppRoutes() {
  return (
    <Routes>
      {/* Pública */}
      <Route path="/login" element={<Login />} />

      {/* Protegidas — requieren sesión */}
      <Route element={<ProtectedRoute />}>
        <Route path="/"                     element={<Dashboard />} />
        <Route path="/turnos"               element={<Turnos />} />
        <Route path="/parcelas"             element={<Parcelas />} />
        <Route path="/parcelas/:id"         element={<ParcelaDetalle />} />
        <Route path="/cultivos"             element={<Cultivos />} />
        <Route path="/cultivos/nueva-siembra" element={<NuevaSiembra />} />
        <Route path="/cosechas"             element={<Cosechas />} />
        <Route path="/cosechas/nueva"       element={<NuevaCosecha />} />
        <Route path="/historial"            element={<Historial />} />
        <Route path="/notificaciones"       element={<Notificaciones />} />
        <Route path="/perfil"               element={<Perfil />} />
      </Route>

      {/* Protegida — solo Coordinadora (rol 1) */}
      <Route element={<ProtectedRoute soloCoordinadora />}>
        <Route path="/coordinacion" element={<Coordinacion />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
