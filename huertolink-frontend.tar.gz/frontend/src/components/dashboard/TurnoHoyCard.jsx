import Card from '../common/Card';
import Badge from '../common/Badge';
import Button from '../common/Button';
import { formatHora, diasRestantes } from '../../utils/formatters';
import './TurnoHoyCard.css';

/**
 * TurnoHoyCard — Responde la pregunta 1 del dashboard:
 * "¿Qué parcela necesita riego hoy y quién es el responsable?"
 */
export default function TurnoHoyCard({ turno, onConfirmar }) {
  const dias = turno.dias_para_cosecha ?? turno.fecha_estimada_cosecha ? diasRestantes(turno.fecha_estimada_cosecha) : null;

  return (
    <Card className="turno-card">
      <div className="turno-card__top">
        <div>
          <span className="turno-card__codigo">{turno.codigo || turno.codigo_parcela}</span>
          <h3 className="turno-card__nombre">{turno.nombre_parcela}</h3>
        </div>
        <Badge color="var(--color-riego)" bg="var(--color-riego-bg)" icon="💧">
          {formatHora(turno.hora_inicio)}
        </Badge>
      </div>

      <p className="turno-card__responsable">
        Responsable: <strong>{turno.responsable}</strong>
      </p>

      {turno.cultivo && (
        <p className="turno-card__cultivo">
          🌿 {turno.cultivo}
          {dias !== null && dias <= 3 && (
            <span className="turno-card__alerta"> · listo en {dias <= 0 ? 'hoy' : `${dias}d`}</span>
          )}
        </p>
      )}

      {turno.estado === 'pendiente' && onConfirmar && (
        <Button size="md" fullWidth onClick={() => onConfirmar(turno)}>
          Confirmar riego
        </Button>
      )}
      {turno.estado === 'completado' && (
        <Badge color="var(--color-success)" bg="var(--color-success-bg)" icon="✓">Riego confirmado</Badge>
      )}
      {turno.estado === 'omitido' && (
        <Badge color="var(--color-danger)" bg="var(--color-danger-bg)" icon="⚠">Turno omitido</Badge>
      )}
    </Card>
  );
}
