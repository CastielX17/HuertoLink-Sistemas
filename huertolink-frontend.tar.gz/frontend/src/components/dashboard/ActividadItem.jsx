import { formatFechaHora } from '../../utils/formatters';
import './ActividadItem.css';

const ICONOS = {
  riego_completado: '💧', riego_omitido: '⚠️', cosecha: '🌾',
  siembra: '🌱', login: '🔓', conflicto: '🚨', consulta: '💬', default: '📋'
};

/** ActividadItem — Una fila del historial de actividad reciente */
export default function ActividadItem({ actividad }) {
  return (
    <div className="actividad-item">
      <span className="actividad-item__icon" aria-hidden="true">
        {ICONOS[actividad.tipo_actividad] || ICONOS.default}
      </span>
      <div className="actividad-item__body">
        <p>{actividad.descripcion}</p>
        <span className="actividad-item__meta">
          {actividad.usuario} · {formatFechaHora(actividad.fecha_hora)}
        </span>
      </div>
    </div>
  );
}
