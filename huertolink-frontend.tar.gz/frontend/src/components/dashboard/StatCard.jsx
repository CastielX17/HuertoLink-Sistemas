import Card from '../common/Card';
import './StatCard.css';

/** StatCard — Número grande + etiqueta, usado en el resumen del dashboard */
export default function StatCard({ icon, value, label, color = 'var(--color-primary-600)' }) {
  return (
    <Card className="stat-card">
      <span className="stat-card__icon" style={{ color }} aria-hidden="true">{icon}</span>
      <span className="stat-card__value">{value}</span>
      <span className="stat-card__label">{label}</span>
    </Card>
  );
}
