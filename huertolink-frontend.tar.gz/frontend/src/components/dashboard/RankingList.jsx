import Card from '../common/Card';
import Avatar from '../common/Avatar';
import ProgressBar from '../common/ProgressBar';
import './RankingList.css';

/** RankingList — Responde pregunta 3: "¿Qué vecinos están más activos?" */
export default function RankingList({ vecinos = [] }) {
  return (
    <Card className="ranking-list">
      {vecinos.map((v, i) => {
        const [nombre, ...resto] = v.vecino.split(' ');
        return (
          <div className="ranking-item" key={v.id_usuario}>
            <span className="ranking-item__pos">{i + 1}</span>
            <Avatar nombre={nombre} apellido={resto.join(' ')} size="sm" />
            <div className="ranking-item__info">
              <div className="row-between">
                <strong>{v.vecino}</strong>
                <span className="ranking-item__pts">{v.puntos_reputacion} pts</span>
              </div>
              {v.logro_titulo && <span className="ranking-item__logro">🏆 {v.logro_titulo}</span>}
              <ProgressBar value={v.pct_cumplimiento || 0} color="var(--color-success)" />
            </div>
          </div>
        );
      })}
    </Card>
  );
}
