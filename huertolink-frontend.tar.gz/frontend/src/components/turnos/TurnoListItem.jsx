import Badge from '../common/Badge';
import { formatFecha, formatHora } from '../../utils/formatters';
import { ESTADO_TURNO } from '../../utils/constants';
import './TurnoListItem.css';

/** TurnoListItem — Fila de turno en el calendario/lista de riego */
export default function TurnoListItem({ turno, onClick }) {
  const estado = ESTADO_TURNO[turno.estado] || {};
  return (
    <button className="turno-item" onClick={onClick}>
      <div className="turno-item__fecha">
        <span className="turno-item__dia">{formatFecha(turno.fecha_turno)}</span>
        <span className="turno-item__hora">{formatHora(turno.hora_inicio)}</span>
      </div>
      <div className="turno-item__info">
        <strong>{turno.nombre_parcela || turno.codigo_parcela}</strong>
        <span className="text-muted">{turno.responsable}</span>
      </div>
      <Badge color={estado.color} bg={estado.bg}>{estado.label}</Badge>
    </button>
  );
}
