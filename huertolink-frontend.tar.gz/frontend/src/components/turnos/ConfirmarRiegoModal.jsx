import { useState } from 'react';
import Modal from '../common/Modal';
import Input from '../common/Input';
import Textarea from '../common/Textarea';
import Button from '../common/Button';

/**
 * ConfirmarRiegoModal — Paso 2-3 del flujo crítico de riego:
 * acción de un toque + verificación con datos opcionales
 * (litros, duración). Diseño simple, sin campos obligatorios extra.
 */
export default function ConfirmarRiegoModal({ open, onClose, onConfirm, parcela, loading }) {
  const [litros, setLitros] = useState('');
  const [minutos, setMinutos] = useState('');

  const handleConfirmar = () => {
    onConfirm({
      cantidad_litros : litros  ? Number(litros)  : undefined,
      duracion_minutos: minutos ? Number(minutos) : undefined
    });
  };

  return (
    <Modal open={open} onClose={onClose} title={`Confirmar riego — ${parcela?.codigo || ''}`} size="sm">
      <div className="stack">
        <p className="text-muted">{parcela?.nombre_parcela || parcela?.nombre}</p>
        <Input label="Litros de agua (opcional)" type="number" inputMode="decimal" min="0"
               value={litros} onChange={(e) => setLitros(e.target.value)} placeholder="Ej: 15" />
        <Input label="Minutos de riego (opcional)" type="number" inputMode="numeric" min="0"
               value={minutos} onChange={(e) => setMinutos(e.target.value)} placeholder="Ej: 20" />
        <Button size="lg" fullWidth loading={loading} onClick={handleConfirmar}>
          Sí, confirmar riego
        </Button>
        <Button variant="outline" size="lg" fullWidth onClick={onClose} disabled={loading}>
          Cancelar
        </Button>
      </div>
    </Modal>
  );
}
