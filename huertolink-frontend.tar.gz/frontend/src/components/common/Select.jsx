import './Input.css';
import './Select.css';

/** Select — Selector accesible, mismo lenguaje visual que Input */
export default function Select({ label, error, hint, id, required, children, ...rest }) {
  const selectId = id || label?.toLowerCase().replaceAll(' ', '-');
  return (
    <div className="field">
      {label && (
        <label htmlFor={selectId} className="field__label">
          {label} {required && <span className="field__required" aria-hidden="true">*</span>}
        </label>
      )}
      <select
        id={selectId}
        className={`field__input field__select ${error ? 'field__input--error' : ''}`}
        aria-invalid={!!error}
        required={required}
        {...rest}
      >
        {children}
      </select>
      {hint && !error && <p className="field__hint">{hint}</p>}
      {error && <p className="field__error" role="alert">{error}</p>}
    </div>
  );
}
