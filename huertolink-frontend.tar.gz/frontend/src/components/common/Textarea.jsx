import './Input.css';
import './Textarea.css';

export default function Textarea({ label, error, hint, id, required, rows = 4, ...rest }) {
  const taId = id || label?.toLowerCase().replaceAll(' ', '-');
  return (
    <div className="field">
      {label && (
        <label htmlFor={taId} className="field__label">
          {label} {required && <span className="field__required" aria-hidden="true">*</span>}
        </label>
      )}
      <textarea
        id={taId}
        rows={rows}
        className={`field__input field__textarea ${error ? 'field__input--error' : ''}`}
        aria-invalid={!!error}
        required={required}
        {...rest}
      />
      {hint && !error && <p className="field__hint">{hint}</p>}
      {error && <p className="field__error" role="alert">{error}</p>}
    </div>
  );
}
