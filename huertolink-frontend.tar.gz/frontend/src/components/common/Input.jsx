import './Input.css';

/**
 * Input — Campo de formulario accesible.
 * Etiqueta siempre visible (no usa placeholder como única referencia),
 * mensaje de error en texto explícito, tamaño de fuente >= 16pt para
 * evitar zoom automático en iOS.
 */
export default function Input({ label, error, hint, id, required, ...rest }) {
  const inputId = id || label?.toLowerCase().replaceAll(' ', '-');
  return (
    <div className="field">
      {label && (
        <label htmlFor={inputId} className="field__label">
          {label} {required && <span className="field__required" aria-hidden="true">*</span>}
        </label>
      )}
      <input
        id={inputId}
        className={`field__input ${error ? 'field__input--error' : ''}`}
        aria-invalid={!!error}
        aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
        required={required}
        {...rest}
      />
      {hint && !error && <p id={`${inputId}-hint`} className="field__hint">{hint}</p>}
      {error && <p id={`${inputId}-error`} className="field__error" role="alert">{error}</p>}
    </div>
  );
}
