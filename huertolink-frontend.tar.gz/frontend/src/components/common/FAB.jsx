import './FAB.css';

/** FAB — Botón flotante de acción primaria (ej: "+ Nueva siembra") */
export default function FAB({ icon = '+', label, onClick, ...rest }) {
  return (
    <button className="fab" onClick={onClick} aria-label={label} {...rest}>
      <span aria-hidden="true">{icon}</span>
      {label && <span className="fab__label">{label}</span>}
    </button>
  );
}
