import { iniciales } from '../../utils/formatters';
import './Avatar.css';

/** Avatar — Iniciales sobre fondo de color (sin depender de fotos) */
export default function Avatar({ nombre = '', apellido = '', size = 'md', src }) {
  if (src) return <img src={src} alt={`${nombre} ${apellido}`} className={`avatar avatar--${size}`} />;
  return (
    <div className={`avatar avatar--${size} avatar--initials`} aria-hidden="true">
      {iniciales(nombre, apellido)}
    </div>
  );
}
