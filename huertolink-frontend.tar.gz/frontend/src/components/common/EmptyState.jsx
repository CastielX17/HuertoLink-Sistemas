import './EmptyState.css';

/**
 * EmptyState — Pantalla vacía como invitación a actuar (no como error).
 * Sigue el principio de escritura: "una pantalla vacía es una invitación a actuar".
 */
export default function EmptyState({ icon = '🌱', title, description, action }) {
  return (
    <div className="empty-state">
      <span className="empty-state__icon" aria-hidden="true">{icon}</span>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action}
    </div>
  );
}
