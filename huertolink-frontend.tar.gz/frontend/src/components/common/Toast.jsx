import './Toast.css';

const ICONS = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' };

/**
 * Toast — Confirmación visual inmediata.
 * Requisito UX: "feedback visual inmediato" tras cada acción
 * (riego confirmado, cosecha registrada, error de red, etc.)
 */
export default function Toast({ message, type = 'success', onClose }) {
  return (
    <div className={`toast toast--${type}`} role="status">
      <span className="toast__icon" aria-hidden="true">{ICONS[type]}</span>
      <span className="toast__message">{message}</span>
      <button className="toast__close" onClick={onClose} aria-label="Cerrar notificación">✕</button>
    </div>
  );
}
