import Button from './Button';
import './ErrorMessage.css';

/** ErrorMessage — Estado de error con acción de reintento explícita */
export default function ErrorMessage({ message, onRetry }) {
  return (
    <div className="error-box" role="alert">
      <span aria-hidden="true">⚠️</span>
      <p>{message || 'No pudimos cargar la información. Intenta nuevamente.'}</p>
      {onRetry && <Button variant="outline" size="md" onClick={onRetry}>Reintentar</Button>}
    </div>
  );
}
