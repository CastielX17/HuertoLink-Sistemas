import './Card.css';

/**
 * Card — Contenedor base con elevación suave.
 * `as` permite usarlo como botón clickeable (NavLink, Link, button…).
 */
export default function Card({ children, padded = true, className = '', onClick, ...rest }) {
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag
      className={`card ${padded ? 'card--padded' : ''} ${onClick ? 'card--clickable' : ''} ${className}`}
      onClick={onClick}
      {...rest}
    >
      {children}
    </Tag>
  );
}
