import './Badge.css';

/** Badge — Etiqueta de estado de alto contraste (riego, cosecha, prioridad…) */
export default function Badge({ children, color, bg, icon }) {
  return (
    <span className="badge" style={{ color, background: bg || 'transparent', borderColor: color }}>
      {icon && <span aria-hidden="true">{icon}</span>}
      {children}
    </span>
  );
}
