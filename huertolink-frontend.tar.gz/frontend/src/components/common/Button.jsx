/**
 * Button — Botón base de HuertoLink.
 * Cumple estándar UX: área táctil mínima 48dp, alto contraste,
 * estado de carga visible, sin animaciones complejas.
 *
 * variant: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost'
 * size:    'md' (48dp, por defecto) | 'lg' (56dp, acciones críticas)
 */
import './Button.css';

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  loading = false,
  icon = null,
  disabled = false,
  type = 'button',
  ...rest
}) {
  return (
    <button
      type={type}
      className={`btn btn--${variant} btn--${size} ${fullWidth ? 'btn--full' : ''}`}
      disabled={disabled || loading}
      aria-busy={loading}
      {...rest}
    >
      {loading ? (
        <span className="btn__spinner" aria-hidden="true" />
      ) : icon ? (
        <span className="btn__icon" aria-hidden="true">{icon}</span>
      ) : null}
      <span>{loading ? 'Cargando…' : children}</span>
    </button>
  );
}
