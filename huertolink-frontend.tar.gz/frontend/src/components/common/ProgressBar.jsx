import './ProgressBar.css';

/** ProgressBar — % de cumplimiento de riego, distribución de cosecha, etc. */
export default function ProgressBar({ value = 0, color = 'var(--color-primary-600)', label }) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className="progress">
      {label && <div className="progress__label">{label}</div>}
      <div className="progress__track" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="progress__fill" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
