import { useEffect, useState } from 'react';
import './UndoToast.css';

/**
 * UndoToast — Paso 5 del flujo crítico (Guía UX/UI):
 * "Ventana de 10 segundos para deshacer la acción en caso de error".
 * Reduce el miedo tecnológico: cualquier acción es reversible.
 */
export default function UndoToast({ message, seconds = 10, onUndo, onExpire }) {
  const [restante, setRestante] = useState(seconds);

  useEffect(() => {
    if (restante <= 0) { onExpire?.(); return; }
    const t = setTimeout(() => setRestante((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [restante, onExpire]);

  const pct = (restante / seconds) * 100;

  return (
    <div className="undo-toast" role="status">
      <div className="undo-toast__bar" style={{ width: `${pct}%` }} aria-hidden="true" />
      <span className="undo-toast__message">{message}</span>
      <button className="undo-toast__btn" onClick={onUndo}>
        Deshacer ({restante}s)
      </button>
    </div>
  );
}
