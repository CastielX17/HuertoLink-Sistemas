import Modal from './Modal';
import Button from './Button';
import './ConfirmDialog.css';

/**
 * ConfirmDialog — Paso 3 del flujo crítico de 5 pasos (Guía UX/UI):
 * "Verificación: cuadro de diálogo simple con botones de gran
 * formato (Sí/No)". Usado antes de confirmar riego, eliminar, etc.
 */
export default function ConfirmDialog({
  open, onClose, onConfirm,
  title = '¿Confirmar acción?',
  description,
  confirmLabel = 'Sí, confirmar',
  cancelLabel = 'No, cancelar',
  variant = 'primary',
  loading = false
}) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm">
      <div className="confirm-dialog">
        {description && <p className="confirm-dialog__desc">{description}</p>}
        <div className="confirm-dialog__actions">
          <Button variant={variant} size="lg" fullWidth loading={loading} onClick={onConfirm}>
            {confirmLabel}
          </Button>
          <Button variant="outline" size="lg" fullWidth onClick={onClose} disabled={loading}>
            {cancelLabel}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
