import './Loader.css';

/** Loader — Indicador de carga centrado, usado en pantallas completas */
export default function Loader({ label = 'Cargando…' }) {
  return (
    <div className="loader" role="status" aria-live="polite">
      <span className="loader__spinner" aria-hidden="true" />
      <p>{label}</p>
    </div>
  );
}
