import Card from '../common/Card';
import Badge from '../common/Badge';
import { ESTADO_PARCELA } from '../../utils/constants';
import './ParcelaCard.css';

/** ParcelaCard — Tarjeta resumen de una parcela en la lista */
export default function ParcelaCard({ parcela, onClick }) {
  const estado = ESTADO_PARCELA[parcela.estado] || {};
  return (
    <Card onClick={onClick} className="parcela-card">
      <div className="parcela-card__top">
        <span className="parcela-card__codigo">{parcela.codigo}</span>
        <Badge color={estado.color}>{estado.label}</Badge>
      </div>
      <h3 className="parcela-card__nombre">{parcela.nombre}</h3>
      <p className="parcela-card__meta">
        {parcela.nombre_vecino ? `👤 ${parcela.nombre_vecino}` : '— Sin asignar'}
        {' · '}{parcela.area_m2} m²
      </p>
      {parcela.es_publica === 1 && <Badge color="var(--color-primary-600)" icon="🌍">Comunitaria</Badge>}
    </Card>
  );
}
