import { useNavigate } from 'react-router-dom';
import './ParcelaMapaGrid.css';

const COLOR_ESTADO = {
  disponible:    'var(--color-info-bg)',
  ocupada:       'var(--color-saludable-bg)',
  mantenimiento: 'var(--color-warning-bg)',
  abandonada:    'var(--color-danger-bg)',
  regalo:        'var(--color-primary-100)'
};

/**
 * ParcelaMapaGrid — Mapa 2D interactivo (cuadrícula Square Foot
 * Gardening). Solo tap, sin pinch/zoom ni drag — según estándar UX.
 */
export default function ParcelaMapaGrid({ parcelas = [] }) {
  const navigate = useNavigate();
  const filas    = Math.max(...parcelas.map((p) => p.ubicacion_fila), 1);
  const columnas = Math.max(...parcelas.map((p) => p.ubicacion_columna), 1);

  const grid = Array.from({ length: filas }, (_, f) =>
    Array.from({ length: columnas }, (_, c) =>
      parcelas.find((p) => p.ubicacion_fila === f + 1 && p.ubicacion_columna === c + 1)
    )
  );

  return (
    <div className="mapa-grid" style={{ gridTemplateColumns: `repeat(${columnas}, 1fr)` }}>
      {grid.flat().map((p, i) =>
        p ? (
          <button
            key={p.id_parcela}
            className="mapa-grid__cell"
            style={{ background: COLOR_ESTADO[p.estado] || 'var(--color-surface-alt)' }}
            onClick={() => navigate(`/parcelas/${p.id_parcela}`)}
            aria-label={`Parcela ${p.codigo}, ${p.nombre}, estado ${p.estado}`}
          >
            <span className="mapa-grid__codigo">{p.codigo.replace('P-', '')}</span>
          </button>
        ) : (
          <div key={`empty-${i}`} className="mapa-grid__cell mapa-grid__cell--empty" aria-hidden="true" />
        )
      )}
    </div>
  );
}
