import { useNavigate } from 'react-router-dom';
import './TopBar.css';

/**
 * TopBar — Barra superior con botón "Volver" siempre visible
 * (navegación lineal tipo Instacart, sin gestos de swipe).
 */
export default function TopBar({ title, onBack, rightAction }) {
  const navigate = useNavigate();
  return (
    <header className="top-bar">
      {onBack !== false && (
        <button className="top-bar__back" onClick={onBack || (() => navigate(-1))} aria-label="Volver">
          ←
        </button>
      )}
      <h1 className="top-bar__title">{title}</h1>
      <div className="top-bar__action">{rightAction}</div>
    </header>
  );
}
