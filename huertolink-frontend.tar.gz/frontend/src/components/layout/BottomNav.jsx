import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './BottomNav.css';

/**
 * BottomNav — Navegación principal mobile-first.
 * Solo 5 destinos (límite recomendado para no sobrecargar
 * cognitivamente a usuarios senior). Iconos + texto, nunca
 * solo iconos, para reconocimiento inmediato.
 */
const ITEMS = [
  { to: '/',             icon: '🏠', label: 'Inicio' },
  { to: '/turnos',       icon: '💧', label: 'Riego' },
  { to: '/parcelas',     icon: '🌱', label: 'Parcelas' },
  { to: '/notificaciones', icon: '🔔', label: 'Avisos' },
  { to: '/perfil',       icon: '👤', label: 'Perfil' }
];

export default function BottomNav() {
  const { esCoordinadora } = useAuth();
  const items = esCoordinadora
    ? [...ITEMS.slice(0, 4), { to: '/coordinacion', icon: '⚙️', label: 'Panel' }]
    : ITEMS;

  return (
    <nav className="bottom-nav" aria-label="Navegación principal">
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.to === '/'}
          className={({ isActive }) => `bottom-nav__item ${isActive ? 'bottom-nav__item--active' : ''}`}
        >
          <span className="bottom-nav__icon" aria-hidden="true">{item.icon}</span>
          <span className="bottom-nav__label">{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
