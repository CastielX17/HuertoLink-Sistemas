import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Loader from '../common/Loader';
import AppShell from './AppShell';

/**
 * ProtectedRoute — Bloquea el acceso a usuarios sin sesión.
 * `soloCoordinadora` restringe además por rol (Panel de Coordinación).
 */
export default function ProtectedRoute({ soloCoordinadora = false }) {
  const { autenticado, cargando, esCoordinadora } = useAuth();

  if (cargando) return <Loader label="Verificando sesión…" />;
  if (!autenticado) return <Navigate to="/login" replace />;
  if (soloCoordinadora && !esCoordinadora) return <Navigate to="/" replace />;

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
