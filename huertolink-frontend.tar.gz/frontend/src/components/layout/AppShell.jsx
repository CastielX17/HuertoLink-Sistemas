import BottomNav from './BottomNav';
import './AppShell.css';

/**
 * AppShell — Envoltorio de página estándar.
 * Usa <TopBar/> dentro de cada página (título dinámico) +
 * <BottomNav/> fijo común a toda la app autenticada.
 */
export default function AppShell({ children }) {
  return (
    <div className="app-shell">
      <main className="app-shell__content">{children}</main>
      <BottomNav />
    </div>
  );
}
