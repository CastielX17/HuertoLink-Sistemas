/** Helpers de formato de fecha/hora/texto reutilizados en toda la app */

export const formatFecha = (fecha, opts = {}) => {
  if (!fecha) return '—';
  const d = new Date(fecha.includes('T') ? fecha : `${fecha}T00:00:00`);
  return d.toLocaleDateString('es-CL', {
    day: 'numeric', month: 'short', year: opts.conAnio ? 'numeric' : undefined
  });
};

export const formatFechaHora = (fechaHora) => {
  if (!fechaHora) return '—';
  const d = new Date(fechaHora.replace(' ', 'T'));
  return d.toLocaleString('es-CL', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
  });
};

export const formatHora = (hora) => {
  if (!hora) return '—';
  return hora.slice(0, 5);
};

export const esHoy = (fecha) => {
  if (!fecha) return false;
  const hoy = new Date().toISOString().split('T')[0];
  return fecha.startsWith(hoy);
};

export const diasRestantes = (fechaFutura) => {
  if (!fechaFutura) return null;
  const hoy = new Date(); hoy.setHours(0,0,0,0);
  const meta = new Date(`${fechaFutura}T00:00:00`);
  return Math.round((meta - hoy) / 86400000);
};

export const iniciales = (nombre = '', apellido = '') =>
  `${nombre.charAt(0)}${apellido.charAt(0)}`.toUpperCase();

export const capitalizar = (texto = '') =>
  texto.charAt(0).toUpperCase() + texto.slice(1).replaceAll('_', ' ');
