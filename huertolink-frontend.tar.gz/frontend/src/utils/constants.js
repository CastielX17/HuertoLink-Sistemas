/** Constantes compartidas de la aplicación */

export const ROLES = {
  COORDINADORA: 1,
  VECINO: 2,
  VOLUNTARIO: 3
};

export const ROL_LABEL = {
  1: 'Coordinadora',
  2: 'Vecino Colaborador',
  3: 'Voluntario Ocasional'
};

export const ESTADO_TURNO = {
  pendiente:  { label: 'Pendiente',  color: 'var(--color-warning)', bg: 'var(--color-warning-bg)' },
  completado: { label: 'Completado', color: 'var(--color-success)', bg: 'var(--color-success-bg)' },
  omitido:    { label: 'Omitido',    color: 'var(--color-danger)',  bg: 'var(--color-danger-bg)' },
  cancelado:  { label: 'Cancelado',  color: 'var(--color-text-muted)', bg: 'var(--color-surface-alt)' }
};

export const ESTADO_PARCELA = {
  disponible:    { label: 'Disponible',    color: 'var(--color-info)' },
  ocupada:       { label: 'Ocupada',       color: 'var(--color-success)' },
  mantenimiento: { label: 'Mantenimiento', color: 'var(--color-warning)' },
  abandonada:    { label: 'Abandonada',    color: 'var(--color-danger)' },
  regalo:        { label: 'Parcela Regalo',color: 'var(--color-primary-600)' }
};

export const ESTADO_OBSERVACION = {
  abierta:     { label: 'Abierta',     color: 'var(--color-danger)' },
  en_proceso:  { label: 'En proceso',  color: 'var(--color-warning)' },
  resuelta:    { label: 'Resuelta',    color: 'var(--color-success)' },
  cerrada:     { label: 'Cerrada',     color: 'var(--color-text-muted)' }
};

export const PRIORIDAD_OBSERVACION = {
  baja:    { label: 'Baja',    color: 'var(--color-text-muted)' },
  media:   { label: 'Media',   color: 'var(--color-info)' },
  alta:    { label: 'Alta',    color: 'var(--color-warning)' },
  urgente: { label: 'Urgente', color: 'var(--color-danger)' }
};

export const TIPO_OBSERVACION_LABEL = {
  incidencia: 'Incidencia',
  vandalismo: 'Vandalismo',
  plaga:      'Plaga',
  mejora:     'Mejora',
  consulta:   'Consulta',
  conflicto:  'Conflicto'
};

export const TIPO_NOTIFICACION_ICON = {
  riego:        '💧',
  cosecha:      '🌾',
  conflicto:    '⚠️',
  sistema:      '🔔',
  recordatorio: '📅',
  logro:        '🏆'
};

export const UNIDADES = ['kg', 'unidad', 'manojo', 'litros', 'gramos'];
