/**
 * useFetch — Hook genérico para llamadas GET con estados de
 * carga/error estandarizados. Evita repetir useState x3 en cada
 * pantalla. `deps` controla cuándo se vuelve a ejecutar la consulta.
 *
 * Uso:
 *   const { data, loading, error, refetch } = useFetch(
 *     () => parcelasService.getParcelas(), []
 *   );
 */
import { useState, useEffect, useCallback, useRef } from 'react';

export function useFetch(fetchFn, deps = []) {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const fnRef = useRef(fetchFn);
  fnRef.current = fetchFn;

  const execute = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fnRef.current();
      setData(res.data ?? res);
    } catch (err) {
      setError(err.message || 'Ocurrió un error al cargar los datos');
    } finally {
      setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => { execute(); }, [execute]);

  return { data, loading, error, refetch: execute, setData };
}
