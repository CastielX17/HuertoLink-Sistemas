/**
 * useDebounce — Retarda un valor (ej. texto de búsqueda) para no
 * disparar una petición a la API en cada tecla presionada.
 */
import { useState, useEffect } from 'react';

export function useDebounce(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}
