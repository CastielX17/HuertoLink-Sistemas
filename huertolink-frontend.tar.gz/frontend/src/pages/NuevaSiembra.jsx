import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import { useToast } from '../context/ToastContext';
import * as parcelasService from '../api/parcelasService';
import * as cultivosService from '../api/cultivosService';
import * as siembrasService from '../api/siembrasService';

import TopBar from '../components/layout/TopBar';
import Select from '../components/common/Select';
import Input from '../components/common/Input';
import Textarea from '../components/common/Textarea';
import Button from '../components/common/Button';
import { UNIDADES } from '../utils/constants';

/**
 * NuevaSiembra — Formulario para registrar una siembra.
 * El backend valida que la parcela no tenga ya una siembra activa
 * (regla que previene el conflicto real del caso "Huerto Herido").
 */
export default function NuevaSiembra() {
  const navigate = useNavigate();
  const [params]  = useSearchParams();
  const { show }  = useToast();

  const { data: parcelas } = useFetch(() => parcelasService.getParcelas({ estado: 'ocupada' }), []);
  const { data: cultivos } = useFetch(() => cultivosService.getCultivos({ activo: 1 }), []);

  const [form, setForm] = useState({
    id_parcela: params.get('parcela') || '',
    id_cultivo: params.get('cultivo') || '',
    fecha_siembra: new Date().toISOString().split('T')[0],
    fecha_estimada_cosecha: '',
    cantidad_sembrada: '',
    unidad_cantidad: 'plantas',
    notas: ''
  });
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');

  // Auto-calcula fecha estimada de cosecha al elegir cultivo
  useEffect(() => {
    if (!form.id_cultivo || !cultivos) return;
    const cultivo = cultivos.find((c) => String(c.id_cultivo) === String(form.id_cultivo));
    if (cultivo) {
      const fecha = new Date(form.fecha_siembra);
      fecha.setDate(fecha.getDate() + cultivo.dias_hasta_cosecha);
      setForm((f) => ({ ...f, fecha_estimada_cosecha: fecha.toISOString().split('T')[0] }));
    }
  }, [form.id_cultivo, form.fecha_siembra, cultivos]);

  const handleChange = (campo) => (e) => setForm((f) => ({ ...f, [campo]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setEnviando(true);
    try {
      await siembrasService.crearSiembra(form);
      show('Siembra registrada correctamente 🌱', 'success');
      navigate('/cultivos');
    } catch (err) {
      setError(err.message);
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div className="page page-with-topbar">
      <TopBar title="Nueva siembra" />

      <form className="stack" onSubmit={handleSubmit}>
        <Select label="Parcela" required value={form.id_parcela} onChange={handleChange('id_parcela')}>
          <option value="">Selecciona una parcela…</option>
          {parcelas?.map((p) => <option key={p.id_parcela} value={p.id_parcela}>{p.codigo} — {p.nombre}</option>)}
        </Select>

        <Select label="Cultivo" required value={form.id_cultivo} onChange={handleChange('id_cultivo')}>
          <option value="">Selecciona un cultivo…</option>
          {cultivos?.map((c) => <option key={c.id_cultivo} value={c.id_cultivo}>{c.nombre_comun}</option>)}
        </Select>

        <Input label="Fecha de siembra" type="date" required value={form.fecha_siembra} onChange={handleChange('fecha_siembra')} />
        <Input label="Fecha estimada de cosecha" type="date" required value={form.fecha_estimada_cosecha} onChange={handleChange('fecha_estimada_cosecha')}
               hint="Se calcula automáticamente, puedes ajustarla" />

        <div className="row" style={{ alignItems: 'flex-end' }}>
          <Input label="Cantidad" type="number" min="0.1" step="0.1" required style={{ flex: 1 }}
                 value={form.cantidad_sembrada} onChange={handleChange('cantidad_sembrada')} />
          <Select label="Unidad" value={form.unidad_cantidad} onChange={handleChange('unidad_cantidad')} style={{ flex: 1 }}>
            <option value="plantas">plantas</option>
            <option value="semillas">semillas</option>
            <option value="m2">m²</option>
            <option value="gramos">gramos</option>
          </Select>
        </div>

        <Textarea label="Notas (opcional)" value={form.notas} onChange={handleChange('notas')} placeholder="Ej: primera siembra del año" />

        {error && <p className="field__error" role="alert">{error}</p>}

        <Button type="submit" size="lg" fullWidth loading={enviando}>Registrar siembra</Button>
      </form>
    </div>
  );
}
