import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import * as cosechasService from '../api/cosechasService';

import TopBar from '../components/layout/TopBar';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import FAB from '../components/common/FAB';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import { formatFecha } from '../utils/formatters';
import './Cosechas.css';

/** Cosechas — Historial de cosechas + resumen del mes */
export default function Cosechas() {
  const navigate = useNavigate();
  const { data, loading, error, refetch } = useFetch(() => cosechasService.getCosechasMes(), []);

  return (
    <div className="page page-with-topbar">
      <TopBar title="Cosechas" onBack={false} />

      {loading && <Loader label="Cargando cosechas…" />}
      {error && <ErrorMessage message={error} onRetry={refetch} />}

      {!loading && !error && (
        <>
          {data?.resumen?.length > 0 && (
            <section className="stack" style={{ marginBottom: 'var(--space-6)' }}>
              <h2 className="section-title">Resumen del mes</h2>
              <div className="cosechas__resumen">
                {data.resumen.map((r) => (
                  <div key={r.cultivo} className="resumen-chip">
                    <strong>{r.total} {r.unidad}</strong>
                    <span>{r.cultivo}</span>
                  </div>
                ))}
              </div>
            </section>
          )}

          <h2 className="section-title">Registros</h2>
          {data?.data?.length === 0 ? (
            <EmptyState icon="🌾" title="Sin cosechas este mes" description="Registra tu primera cosecha del mes." />
          ) : (
            <div className="stack">
              {data?.data?.map((c) => (
                <Card key={c.id_cosecha} className="cosecha-row">
                  <div className="row-between">
                    <strong>{c.cultivo}</strong>
                    <Badge color={c.es_distribuida ? 'var(--color-success)' : 'var(--color-warning)'}>
                      {c.es_distribuida ? 'Distribuida' : 'Pendiente'}
                    </Badge>
                  </div>
                  <p className="text-muted">{formatFecha(c.fecha_cosecha)} · {c.codigo_parcela} · {c.cosechador}</p>
                  <p>{c.cantidad_cosechada} {c.unidad}</p>
                  {c.distribucion_descripcion && <p className="text-muted">{c.distribucion_descripcion}</p>}
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      <FAB icon="+" label="Nueva cosecha" onClick={() => navigate('/cosechas/nueva')} />
    </div>
  );
}
