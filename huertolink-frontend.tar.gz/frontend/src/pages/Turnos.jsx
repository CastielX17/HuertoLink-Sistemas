import { useState, useMemo } from 'react';
import { useFetch } from '../hooks/useFetch';
import { useToast } from '../context/ToastContext';
import * as turnosService from '../api/turnosService';

import TopBar from '../components/layout/TopBar';
import TurnoListItem from '../components/turnos/TurnoListItem';
import ConfirmarRiegoModal from '../components/turnos/ConfirmarRiegoModal';
import Modal from '../components/common/Modal';
import Badge from '../components/common/Badge';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import { ESTADO_TURNO } from '../utils/constants';
import { formatFecha, formatHora } from '../utils/formatters';
import './Turnos.css';

const FILTROS = [
  { key: 'todos',      label: 'Todos' },
  { key: 'pendiente',  label: 'Pendientes' },
  { key: 'completado', label: 'Completados' },
  { key: 'omitido',    label: 'Omitidos' }
];

/**
 * Turnos — Calendario y lista de turnos de riego.
 * Navegación lineal (sin swipe): filtros como chips horizontales,
 * lista vertical simple ordenada por fecha.
 */
export default function Turnos() {
  const { show } = useToast();
  const [filtro, setFiltro]   = useState('todos');
  const [detalle, setDetalle] = useState(null);
  const [confirmar, setConfirmar] = useState(null);
  const [loadingAccion, setLoadingAccion] = useState(false);

  const { data, loading, error, refetch } = useFetch(
    () => turnosService.getTurnos(filtro !== 'todos' ? { estado: filtro } : {}),
    [filtro]
  );

  const turnos = useMemo(() => data || [], [data]);

  const handleConfirmarRiego = async (extra) => {
    setLoadingAccion(true);
    try {
      await turnosService.confirmarRiego(confirmar.id_turno, extra);
      show('Riego confirmado correctamente 💧', 'success');
      setConfirmar(null);
      setDetalle(null);
      refetch();
    } catch (err) {
      show(err.message, 'error');
    } finally {
      setLoadingAccion(false);
    }
  };

  return (
    <div className="page page-with-topbar">
      <TopBar title="Calendario de riego" onBack={false} />

      <div className="turnos__filtros" role="tablist" aria-label="Filtrar turnos">
        {FILTROS.map((f) => (
          <button
            key={f.key}
            role="tab"
            aria-selected={filtro === f.key}
            className={`chip ${filtro === f.key ? 'chip--active' : ''}`}
            onClick={() => setFiltro(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading && <Loader label="Cargando turnos…" />}
      {error && <ErrorMessage message={error} onRetry={refetch} />}

      {!loading && !error && turnos.length === 0 && (
        <EmptyState icon="💧" title="Sin turnos" description="No hay turnos de riego para este filtro." />
      )}

      {!loading && !error && turnos.length > 0 && (
        <div className="stack">
          {turnos.map((t) => (
            <TurnoListItem key={t.id_turno} turno={t} onClick={() => setDetalle(t)} />
          ))}
        </div>
      )}

      {/* Detalle del turno seleccionado */}
      <Modal open={!!detalle} onClose={() => setDetalle(null)} title="Detalle del turno" size="sm">
        {detalle && (
          <div className="stack">
            <div className="row-between">
              <strong>{detalle.nombre_parcela}</strong>
              <Badge color={ESTADO_TURNO[detalle.estado]?.color} bg={ESTADO_TURNO[detalle.estado]?.bg}>
                {ESTADO_TURNO[detalle.estado]?.label}
              </Badge>
            </div>
            <p className="text-muted">{formatFecha(detalle.fecha_turno, { conAnio: true })} · {formatHora(detalle.hora_inicio)} - {formatHora(detalle.hora_fin)}</p>
            <p>Responsable: <strong>{detalle.responsable}</strong></p>
            {detalle.cultivo_sembrado && <p>Cultivo: {detalle.cultivo_sembrado}</p>}
            {detalle.notas && <p className="text-muted">Nota: {detalle.notas}</p>}

            {detalle.estado === 'pendiente' && (
              <Button size="lg" fullWidth onClick={() => setConfirmar(detalle)}>
                Confirmar riego
              </Button>
            )}
          </div>
        )}
      </Modal>

      <ConfirmarRiegoModal
        open={!!confirmar}
        parcela={confirmar}
        loading={loadingAccion}
        onClose={() => setConfirmar(null)}
        onConfirm={handleConfirmarRiego}
      />
    </div>
  );
}
