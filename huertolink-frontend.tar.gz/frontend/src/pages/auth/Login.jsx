import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import './Login.css';

/**
 * Login — Pantalla de inicio de sesión.
 * Diseño de un solo paso, sin distracciones, alto contraste,
 * botón de acción único y grande (56px), mensajes de error
 * explícitos en español sencillo.
 */
export default function Login() {
  const { login } = useAuth();
  const { show } = useToast();
  const navigate  = useNavigate();

  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      show('¡Bienvenido a HuertoLink!', 'success');
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message || 'Email o contraseña incorrectos');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-page__hero">
        <span className="login-page__logo" aria-hidden="true">🌱</span>
        <h1>HuertoLink</h1>
        <p>Tu huerto, conectado</p>
      </div>

      <form className="login-page__form stack" onSubmit={handleSubmit}>
        <h2 className="fs-title">Inicia sesión</h2>

        <Input
          label="Correo electrónico" type="email" required
          value={email} onChange={(e) => setEmail(e.target.value)}
          placeholder="tu.nombre@huertolink.cl" autoComplete="email"
        />
        <Input
          label="Contraseña" type="password" required
          value={password} onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••" autoComplete="current-password"
        />

        {error && <p className="field__error" role="alert">{error}</p>}

        <Button type="submit" size="lg" fullWidth loading={loading}>
          Ingresar
        </Button>

        <p className="login-page__ayuda text-center text-muted">
          ¿Olvidaste tu contraseña? Pídele ayuda a la Coordinadora del huerto.
        </p>
      </form>
    </div>
  );
}
