import { useFetch } from '../hooks/useFetch';
import * as dashboardService from '../api/dashboardService';

import TopBar from '../components/layout/TopBar';
import ActividadItem from '../components/dashboard/ActividadItem';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import Card from '../components/common/Card';

/**
 * Historial — Registro completo de actividades del huerto.
 * Reemplaza el "grupo de WhatsApp con 300 mensajes diarios"
 * con un log estructurado, ordenado y filtrable.
 */
export default function Historial() {
  const { data, loading, error, refetch } = useFetch(() => dashboardService.getDashboard(), []);

  return (
    <div className="page page-with-topbar">
      <TopBar title="Historial de actividad" onBack={false} />

      {loading && <Loader label="Cargando historial…" />}
      {error && <ErrorMessage message={error} onRetry={refetch} />}

      {!loading && !error && (
        data?.data?.actividad_reciente?.length === 0 ? (
          <EmptyState icon="📋" title="Sin actividad aún" description="Las acciones del huerto aparecerán aquí." />
        ) : (
          <Card style={{ padding: 'var(--space-4)' }}>
            {data?.data?.actividad_reciente?.map((a) => (
              <ActividadItem key={a.id_actividad} actividad={a} />
            ))}
          </Card>
        )
      )}
    </div>
  );
}
