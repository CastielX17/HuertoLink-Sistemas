import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

import TopBar from '../components/layout/TopBar';
import Avatar from '../components/common/Avatar';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import Button from '../components/common/Button';
import { ROL_LABEL } from '../utils/constants';
import './Perfil.css';

/** Perfil — Datos del usuario, puntos de reputación y logros */
export default function Perfil() {
  const { usuario, logout } = useAuth();
  const { show } = useToast();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    show('Sesión cerrada. ¡Hasta pronto! 👋', 'info');
    navigate('/login', { replace: true });
  };

  return (
    <div className="page page-with-topbar">
      <TopBar title="Mi perfil" onBack={false} />

      <div className="perfil__header">
        <Avatar nombre={usuario?.nombre} apellido={usuario?.apellido} size="lg" />
        <h2>{usuario?.nombre} {usuario?.apellido}</h2>
        <Badge color="var(--color-primary-600)" bg="var(--color-primary-100)">
          {ROL_LABEL[usuario?.id_rol]}
        </Badge>
      </div>

      <div className="perfil__stats">
        <Card className="perfil__stat">
          <span className="perfil__stat-value">{usuario?.puntos_reputacion ?? 0}</span>
          <span className="text-muted">Puntos de reputación</span>
        </Card>
        {usuario?.logro_titulo && (
          <Card className="perfil__stat">
            <span className="perfil__stat-value">🏆</span>
            <span className="text-muted">{usuario.logro_titulo}</span>
          </Card>
        )}
      </div>

      <Card className="stack-sm">
        <h3 className="section-title">Información de contacto</h3>
        <p>📧 {usuario?.email}</p>
        <p>📱 {usuario?.telefono || 'No registrado'}</p>
      </Card>

      <div style={{ marginTop: 'var(--space-8)' }}>
        <Button variant="outline" size="lg" fullWidth onClick={handleLogout}>
          Cerrar sesión
        </Button>
      </div>
    </div>
  );
}
