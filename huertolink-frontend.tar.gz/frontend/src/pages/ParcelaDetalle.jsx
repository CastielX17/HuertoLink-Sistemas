import { useParams, useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import * as parcelasService from '../api/parcelasService';

import TopBar from '../components/layout/TopBar';
import Badge from '../components/common/Badge';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import { ESTADO_PARCELA } from '../utils/constants';
import { formatFecha } from '../utils/formatters';
import './ParcelaDetalle.css';

/** ParcelaDetalle — Ficha de una parcela: estado, responsable, siembras */
export default function ParcelaDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: parcela, loading, error, refetch } = useFetch(() => parcelasService.getParcela(id), [id]);

  if (loading) return <Loader label="Cargando parcela…" />;
  if (error)   return <ErrorMessage message={error} onRetry={refetch} />;
  if (!parcela) return null;

  const estado = ESTADO_PARCELA[parcela.estado] || {};
  const siembraActiva = parcela.siembras?.find((s) => s.estado === 'activa');

  return (
    <div className="page page-with-topbar">
      <TopBar title={parcela.codigo} />

      <div className="parcela-detalle stack-lg">
        <Card>
          <div className="row-between" style={{ marginBottom: 'var(--space-3)' }}>
            <h2>{parcela.nombre}</h2>
            <Badge color={estado.color}>{estado.label}</Badge>
          </div>
          <div className="stack-sm">
            <p>👤 {parcela.nombre_vecino || 'Sin vecino asignado'}</p>
            <p>📐 {parcela.area_m2} m² · Fila {parcela.ubicacion_fila}, Columna {parcela.ubicacion_columna}</p>
            {parcela.es_publica === 1 && <p>🌍 Parcela comunitaria</p>}
            {parcela.descripcion && <p className="text-muted">{parcela.descripcion}</p>}
          </div>
        </Card>

        {siembraActiva && (
          <Card>
            <h3 className="section-title">🌱 Siembra activa</h3>
            <div className="stack-sm">
              <p><strong>{siembraActiva.nombre_comun}</strong> — sembrado por {siembraActiva.sembrador}</p>
              <p className="text-muted">Cosecha estimada: {formatFecha(siembraActiva.fecha_estimada_cosecha, { conAnio: true })}</p>
              <p>{siembraActiva.cantidad_sembrada} {siembraActiva.unidad_cantidad}</p>
            </div>
          </Card>
        )}

        <section>
          <h3 className="section-title">Historial de siembras</h3>
          {!parcela.siembras || parcela.siembras.length === 0 ? (
            <EmptyState icon="🌿" title="Sin siembras registradas" />
          ) : (
            <div className="stack-sm">
              {parcela.siembras.map((s) => (
                <Card key={s.id_siembra} padded={false} className="siembra-row">
                  <div className="siembra-row__color" style={{ background: s.color_mapa }} />
                  <div className="siembra-row__info">
                    <strong>{s.nombre_comun}</strong>
                    <span className="text-muted">{formatFecha(s.fecha_siembra)} · {s.sembrador}</span>
                  </div>
                  <Badge color={s.estado === 'perdida' ? 'var(--color-danger)' : 'var(--color-text-muted)'}>
                    {s.estado}
                  </Badge>
                </Card>
              ))}
            </div>
          )}
        </section>

        <Button size="lg" fullWidth onClick={() => navigate(`/cultivos/nueva-siembra?parcela=${id}`)}>
          + Registrar nueva siembra
        </Button>
      </div>
    </div>
  );
}
