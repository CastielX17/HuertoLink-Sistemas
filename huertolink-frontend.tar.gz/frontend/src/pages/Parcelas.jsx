import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import { useAuth } from '../context/AuthContext';
import * as parcelasService from '../api/parcelasService';

import TopBar from '../components/layout/TopBar';
import ParcelaCard from '../components/parcelas/ParcelaCard';
import ParcelaMapaGrid from '../components/parcelas/ParcelaMapaGrid';
import FAB from '../components/common/FAB';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import './Parcelas.css';

/**
 * Parcelas — Vista de mapa 2D + lista de parcelas.
 * Alterna entre "Mapa" y "Lista" con un simple toggle (sin gestos).
 */
export default function Parcelas() {
  const navigate = useNavigate();
  const { esCoordinadora } = useAuth();
  const [vista, setVista] = useState('mapa');
  const { data: parcelas, loading, error, refetch } = useFetch(() => parcelasService.getParcelas(), []);

  return (
    <div className="page page-with-topbar">
      <TopBar title="Parcelas del huerto" onBack={false} />

      <div className="parcelas__toggle" role="tablist">
        <button role="tab" aria-selected={vista === 'mapa'} className={`chip ${vista === 'mapa' ? 'chip--active' : ''}`} onClick={() => setVista('mapa')}>🗺️ Mapa</button>
        <button role="tab" aria-selected={vista === 'lista'} className={`chip ${vista === 'lista' ? 'chip--active' : ''}`} onClick={() => setVista('lista')}>📋 Lista</button>
      </div>

      {loading && <Loader label="Cargando parcelas…" />}
      {error && <ErrorMessage message={error} onRetry={refetch} />}

      {!loading && !error && parcelas?.length === 0 && (
        <EmptyState icon="🌱" title="Sin parcelas" description="Aún no se han creado parcelas en el huerto." />
      )}

      {!loading && !error && parcelas?.length > 0 && vista === 'mapa' && (
        <>
          <ParcelaMapaGrid parcelas={parcelas} />
          <div className="parcelas__leyenda">
            <span><i style={{ background: 'var(--color-saludable-bg)' }} /> Ocupada</span>
            <span><i style={{ background: 'var(--color-info-bg)' }} /> Disponible</span>
            <span><i style={{ background: 'var(--color-warning-bg)' }} /> Mantenimiento</span>
            <span><i style={{ background: 'var(--color-primary-100)' }} /> Regalo</span>
          </div>
        </>
      )}

      {!loading && !error && parcelas?.length > 0 && vista === 'lista' && (
        <div className="stack">
          {parcelas.map((p) => (
            <ParcelaCard key={p.id_parcela} parcela={p} onClick={() => navigate(`/parcelas/${p.id_parcela}`)} />
          ))}
        </div>
      )}

      {esCoordinadora && <FAB icon="+" label="Nueva parcela" onClick={() => navigate('/parcelas/nueva')} />}
    </div>
  );
}
