import { useFetch } from '../hooks/useFetch';
import { useToast } from '../context/ToastContext';
import * as notifService from '../api/notificacionesService';

import TopBar from '../components/layout/TopBar';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import { TIPO_NOTIFICACION_ICON } from '../utils/constants';
import { formatFechaHora } from '../utils/formatters';
import './Notificaciones.css';

/** Notificaciones — Centro de avisos personales (reemplaza WhatsApp) */
export default function Notificaciones() {
  const { show } = useToast();
  const { data, loading, error, refetch } = useFetch(() => notifService.getMisNotificaciones(), []);

  const handleLeer = async (id) => {
    try { await notifService.marcarLeida(id); refetch(); } catch (e) { show(e.message, 'error'); }
  };

  const handleLeerTodas = async () => {
    try {
      await notifService.marcarTodasLeidas();
      show('Todas las notificaciones marcadas como leídas', 'success');
      refetch();
    } catch (e) { show(e.message, 'error'); }
  };

  return (
    <div className="page page-with-topbar">
      <TopBar
        title="Notificaciones"
        onBack={false}
        rightAction={data?.no_leidas > 0 && (
          <button className="link-button" onClick={handleLeerTodas}>Marcar todas</button>
        )}
      />

      {loading && <Loader label="Cargando avisos…" />}
      {error && <ErrorMessage message={error} onRetry={refetch} />}

      {!loading && !error && (
        data?.data?.length === 0 ? (
          <EmptyState icon="🔔" title="Sin notificaciones" description="Aquí aparecerán tus avisos de riego, cosechas y novedades del huerto." />
        ) : (
          <div className="stack-sm">
            {data?.data?.map((n) => (
              <Card
                key={n.id_notificacion}
                onClick={!n.leida ? () => handleLeer(n.id_notificacion) : undefined}
                className={`notif-card ${!n.leida ? 'notif-card--unread' : ''}`}
              >
                <div className="row">
                  <span className="notif-card__icon" aria-hidden="true">{TIPO_NOTIFICACION_ICON[n.tipo] || '🔔'}</span>
                  <div className="notif-card__body">
                    <strong>{n.titulo}</strong>
                    <p>{n.mensaje}</p>
                    <span className="text-muted">{formatFechaHora(n.fecha_creacion)}</span>
                  </div>
                  {!n.leida && <span className="notif-card__dot" aria-label="No leída" />}
                </div>
              </Card>
            ))}
          </div>
        )
      )}
    </div>
  );
}
