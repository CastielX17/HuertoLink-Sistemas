import { useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import * as cultivosService from '../api/cultivosService';

import TopBar from '../components/layout/TopBar';
import Card from '../components/common/Card';
import FAB from '../components/common/FAB';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import './Cultivos.css';

/** Cultivos — Catálogo de especies disponibles para sembrar */
export default function Cultivos() {
  const navigate = useNavigate();
  const { data: cultivos, loading, error, refetch } = useFetch(() => cultivosService.getCultivos({ activo: 1 }), []);

  if (loading) return <Loader label="Cargando catálogo…" />;
  if (error)   return <ErrorMessage message={error} onRetry={refetch} />;

  return (
    <div className="page page-with-topbar">
      <TopBar title="Catálogo de cultivos" onBack={false} />

      <div className="cultivos-grid">
        {cultivos?.map((c) => (
          <Card key={c.id_cultivo} onClick={() => navigate(`/cultivos/nueva-siembra?cultivo=${c.id_cultivo}`)} className="cultivo-card">
            <div className="cultivo-card__chip" style={{ background: c.color_mapa }} aria-hidden="true" />
            <strong>{c.nombre_comun}</strong>
            <span className="text-muted">💧 cada {c.frecuencia_riego_dias}d · 🌾 {c.dias_hasta_cosecha}d</span>
          </Card>
        ))}
      </div>

      <FAB icon="🌱" label="Nueva siembra" onClick={() => navigate('/cultivos/nueva-siembra')} />
    </div>
  );
}
