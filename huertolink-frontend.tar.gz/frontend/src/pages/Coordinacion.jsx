import { useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';
import * as observacionesService from '../api/observacionesService';
import * as dashboardService from '../api/dashboardService';

import TopBar from '../components/layout/TopBar';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import StatCard from '../components/dashboard/StatCard';
import Modal from '../components/common/Modal';
import Select from '../components/common/Select';
import Textarea from '../components/common/Textarea';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import {
  ESTADO_OBSERVACION, PRIORIDAD_OBSERVACION, TIPO_OBSERVACION_LABEL
} from '../utils/constants';
import { formatFecha } from '../utils/formatters';
import './Coordinacion.css';

/**
 * Coordinacion — Panel exclusivo para la Coordinadora.
 * Gestiona observaciones/incidencias (robos, conflictos, plagas)
 * y muestra alertas de vecinos en riesgo de abandono.
 * Solo accesible si esCoordinadora === true (ver ProtectedRoute).
 */
export default function Coordinacion() {
  const { show } = useToast();
  const [filtroEstado, setFiltroEstado] = useState('abierta');
  const [seleccionada, setSeleccionada] = useState(null);
  const [resolucion, setResolucion] = useState('');
  const [guardando, setGuardando] = useState(false);

  const { data: dash } = useFetch(() => dashboardService.getDashboard(), []);
  const { data: observaciones, loading, error, refetch } = useFetch(
    () => observacionesService.getObservaciones(filtroEstado !== 'todas' ? { estado: filtroEstado } : {}),
    [filtroEstado]
  );

  const handleResolver = async () => {
    setGuardando(true);
    try {
      await observacionesService.actualizarObservacion(seleccionada.id_observacion, {
        estado: 'resuelta',
        notas_resolucion: resolucion
      });
      show('Incidencia marcada como resuelta ✓', 'success');
      setSeleccionada(null);
      setResolucion('');
      refetch();
    } catch (err) {
      show(err.message, 'error');
    } finally {
      setGuardando(false);
    }
  };

  return (
    <div className="page page-with-topbar">
      <TopBar title="Panel de Coordinación" onBack={false} />

      {dash?.data && (
        <div className="coord__stats">
          <StatCard icon="🌱" value={dash.data.estadisticas.total_vecinos} label="Vecinos activos" />
          <StatCard icon="🏡" value={dash.data.estadisticas.parcelas_ocupadas} label="Parcelas ocupadas" />
          <StatCard icon="🚨" value={dash.data.estadisticas.alertas_activas} label="Alertas activas" color="var(--color-danger)" />
          <StatCard icon="⏳" value={dash.data.alertas.vecinos_inactivos?.length || 0} label="Riesgo abandono" color="var(--color-warning)" />
        </div>
      )}

      <section className="stack" style={{ marginTop: 'var(--space-6)' }}>
        <h2 className="section-title">Incidencias y observaciones</h2>

        <div className="coord__filtros">
          {['abierta', 'en_proceso', 'resuelta', 'todas'].map((f) => (
            <button key={f} className={`chip ${filtroEstado === f ? 'chip--active' : ''}`} onClick={() => setFiltroEstado(f)}>
              {f === 'todas' ? 'Todas' : ESTADO_OBSERVACION[f]?.label}
            </button>
          ))}
        </div>

        {loading && <Loader label="Cargando incidencias…" />}
        {error && <ErrorMessage message={error} onRetry={refetch} />}

        {!loading && !error && observaciones?.length === 0 && (
          <EmptyState icon="✅" title="Todo en orden" description="No hay incidencias en este filtro." />
        )}

        {!loading && !error && observaciones?.length > 0 && (
          <div className="stack-sm">
            {observaciones.map((o) => (
              <Card
                key={o.id_observacion}
                onClick={o.estado !== 'resuelta' ? () => setSeleccionada(o) : undefined}
                className="obs-card"
              >
                <div className="row-between">
                  <Badge color={PRIORIDAD_OBSERVACION[o.prioridad]?.color}>
                    {PRIORIDAD_OBSERVACION[o.prioridad]?.label}
                  </Badge>
                  <Badge color={ESTADO_OBSERVACION[o.estado]?.color}>
                    {ESTADO_OBSERVACION[o.estado]?.label}
                  </Badge>
                </div>
                <strong>{o.titulo}</strong>
                <p className="text-muted">{TIPO_OBSERVACION_LABEL[o.tipo]} · {o.codigo_parcela || 'General'} · {formatFecha(o.fecha_reporte)}</p>
                <p>{o.descripcion}</p>
                {o.reportado_por && <span className="text-muted">Reportado por {o.reportado_por}</span>}
              </Card>
            ))}
          </div>
        )}
      </section>

      <Modal open={!!seleccionada} onClose={() => setSeleccionada(null)} title="Resolver incidencia" size="sm">
        {seleccionada && (
          <div className="stack">
            <p><strong>{seleccionada.titulo}</strong></p>
            <p className="text-muted">{seleccionada.descripcion}</p>
            <Textarea
              label="Notas de resolución"
              value={resolucion}
              onChange={(e) => setResolucion(e.target.value)}
              placeholder="¿Cómo se resolvió esta incidencia?"
            />
            <Button size="lg" fullWidth loading={guardando} onClick={handleResolver}>
              Marcar como resuelta
            </Button>
          </div>
        )}
      </Modal>
    </div>
  );
}
