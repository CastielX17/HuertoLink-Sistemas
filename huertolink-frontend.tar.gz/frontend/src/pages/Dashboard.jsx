import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import * as dashboardService from '../api/dashboardService';
import * as turnosService from '../api/turnosService';

import Avatar from '../components/common/Avatar';
import StatCard from '../components/dashboard/StatCard';
import TurnoHoyCard from '../components/dashboard/TurnoHoyCard';
import RankingList from '../components/dashboard/RankingList';
import ActividadItem from '../components/dashboard/ActividadItem';
import ConfirmarRiegoModal from '../components/turnos/ConfirmarRiegoModal';
import Loader from '../components/common/Loader';
import ErrorMessage from '../components/common/ErrorMessage';
import EmptyState from '../components/common/EmptyState';
import Badge from '../components/common/Badge';
import './Dashboard.css';

/**
 * Dashboard — Pantalla principal. Responde directamente las
 * preguntas del caso "Huerto Herido":
 *   1. ¿Qué parcelas necesitan riego hoy y quién es responsable?
 *   2. ¿Cuánto se ha cosechado este mes?
 *   3. ¿Qué vecinos están más activos?
 * + actividad reciente y alertas de abandono.
 */
export default function Dashboard() {
  const { usuario } = useAuth();
  const { show }     = useToast();
  const navigate     = useNavigate();
  const { data, loading, error, refetch } = useFetch(() => dashboardService.getDashboard(), []);

  const [turnoSel, setTurnoSel] = useState(null);
  const [confirmando, setConfirmando] = useState(false);

  if (loading) return <Loader label="Cargando tu huerto…" />;
  if (error)   return <ErrorMessage message={error} onRetry={refetch} />;
  if (!data)   return null;

  const { estadisticas, turnos_hoy, cosechas_mes, ranking_vecinos, actividad_reciente, alertas } = data;

  const handleConfirmarRiego = async (extra) => {
    setConfirmando(true);
    try {
      await turnosService.confirmarRiego(turnoSel.id_turno, extra);
      show('Riego confirmado. +10 puntos de reputación 🌟', 'success');
      setTurnoSel(null);
      refetch();
    } catch (err) {
      show(err.message, 'error');
    } finally {
      setConfirmando(false);
    }
  };

  return (
    <div className="page page-with-topbar dashboard">
      <header className="dashboard__header">
        <div>
          <p className="text-muted">Hola,</p>
          <h1>{usuario?.nombre} 👋</h1>
        </div>
        <Avatar nombre={usuario?.nombre} apellido={usuario?.apellido} size="md" />
      </header>

      {/* ── Estadísticas rápidas ────────────────────────────── */}
      <div className="dashboard__stats">
        <StatCard icon="💧" value={estadisticas.pendientes_hoy} label="Riegos pendientes hoy" color="var(--color-riego)" />
        <StatCard icon="✓"  value={estadisticas.completados_hoy} label="Riegos completados" color="var(--color-success)" />
        <StatCard icon="🌱" value={estadisticas.siembras_activas} label="Siembras activas" color="var(--color-primary-600)" />
        <StatCard icon="⚠️" value={estadisticas.alertas_activas} label="Alertas activas" color="var(--color-danger)" />
      </div>

      {/* ── Pregunta 1: Turnos de riego de hoy ──────────────── */}
      <section className="stack">
        <div className="row-between">
          <h2 className="section-title">Riego de hoy</h2>
          <button className="link-button" onClick={() => navigate('/turnos')}>Ver calendario →</button>
        </div>

        {turnos_hoy.pendientes.length === 0 && turnos_hoy.completados.length === 0 ? (
          <EmptyState icon="✅" title="Sin turnos hoy" description="No hay riegos programados para hoy." />
        ) : (
          <div className="stack">
            {turnos_hoy.pendientes.map((t) => (
              <TurnoHoyCard key={t.id_turno} turno={t} onConfirmar={setTurnoSel} />
            ))}
            {turnos_hoy.completados.map((t) => (
              <TurnoHoyCard key={t.id_turno} turno={t} />
            ))}
          </div>
        )}
      </section>

      {/* ── Alertas de abandono ──────────────────────────────── */}
      {alertas.vecinos_inactivos?.length > 0 && (
        <section className="stack">
          <h2 className="section-title">⚠️ Riesgo de abandono</h2>
          <div className="dashboard__alertas">
            {alertas.vecinos_inactivos.slice(0, 3).map((v) => (
              <div className="alerta-item" key={`${v.id_usuario}-${v.codigo}`}>
                <span><strong>{v.vecino}</strong> — {v.nombre_parcela}</span>
                <Badge color="var(--color-danger)" bg="var(--color-danger-bg)">
                  {v.dias_sin_actividad ?? '?'} días sin actividad
                </Badge>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ── Pregunta 2: Cosechas del mes ─────────────────────── */}
      <section className="stack">
        <h2 className="section-title">🌾 Cosechas de este mes</h2>
        {cosechas_mes.length === 0 ? (
          <EmptyState icon="🌾" title="Aún sin cosechas" description="Este mes todavía no se ha registrado ninguna cosecha." />
        ) : (
          <div className="dashboard__cosechas">
            {cosechas_mes.map((c) => (
              <div className="cosecha-chip" key={c.cultivo}>
                <strong>{c.total} {c.unidad}</strong>
                <span>{c.cultivo}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ── Pregunta 3: Vecinos más activos ──────────────────── */}
      <section className="stack">
        <h2 className="section-title">🏆 Vecinos más activos</h2>
        <RankingList vecinos={ranking_vecinos.slice(0, 5)} />
      </section>

      {/* ── Actividad reciente ────────────────────────────────── */}
      <section className="stack">
        <h2 className="section-title">Actividad reciente</h2>
        {actividad_reciente.length === 0 ? (
          <EmptyState icon="📋" title="Sin actividad reciente" />
        ) : (
          <div className="card" style={{ padding: 'var(--space-4)' }}>
            {actividad_reciente.slice(0, 8).map((a) => (
              <ActividadItem key={a.id_actividad} actividad={a} />
            ))}
          </div>
        )}
      </section>

      <ConfirmarRiegoModal
        open={!!turnoSel}
        parcela={turnoSel}
        loading={confirmando}
        onClose={() => setTurnoSel(null)}
        onConfirm={handleConfirmarRiego}
      />
    </div>
  );
}
