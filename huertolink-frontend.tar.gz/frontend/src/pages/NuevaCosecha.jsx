import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFetch } from '../hooks/useFetch';
import { useToast } from '../context/ToastContext';
import * as siembrasService from '../api/siembrasService';
import * as cosechasService from '../api/cosechasService';

import TopBar from '../components/layout/TopBar';
import Select from '../components/common/Select';
import Input from '../components/common/Input';
import Textarea from '../components/common/Textarea';
import Button from '../components/common/Button';

/** NuevaCosecha — Registrar una cosecha y cómo se distribuye (resuelve el incidente de la lechuga del caso) */
export default function NuevaCosecha() {
  const navigate = useNavigate();
  const { show }  = useToast();
  const { data: siembras } = useFetch(() => siembrasService.getSiembras({ estado: 'activa' }), []);

  const [form, setForm] = useState({
    id_siembra: '', fecha_cosecha: new Date().toISOString().split('T')[0],
    cantidad_cosechada: '', unidad: 'kg', distribucion_descripcion: '',
    es_distribuida: false, marcar_cosechada: false
  });
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (campo) => (e) =>
    setForm((f) => ({ ...f, [campo]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setEnviando(true);
    try {
      await cosechasService.crearCosecha(form);
      show('Cosecha registrada correctamente 🌾 +20 puntos', 'success');
      navigate('/cosechas');
    } catch (err) {
      setError(err.message);
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div className="page page-with-topbar">
      <TopBar title="Registrar cosecha" />

      <form className="stack" onSubmit={handleSubmit}>
        <Select label="Siembra" required value={form.id_siembra} onChange={handleChange('id_siembra')}>
          <option value="">Selecciona la siembra cosechada…</option>
          {siembras?.map((s) => (
            <option key={s.id_siembra} value={s.id_siembra}>{s.codigo_parcela} — {s.cultivo}</option>
          ))}
        </Select>

        <Input label="Fecha de cosecha" type="date" required value={form.fecha_cosecha} onChange={handleChange('fecha_cosecha')} />

        <div className="row" style={{ alignItems: 'flex-end' }}>
          <Input label="Cantidad" type="number" min="0.01" step="0.01" required style={{ flex: 1 }}
                 value={form.cantidad_cosechada} onChange={handleChange('cantidad_cosechada')} />
          <Select label="Unidad" value={form.unidad} onChange={handleChange('unidad')} style={{ flex: 1 }}>
            <option value="kg">kg</option><option value="unidad">unidad</option>
            <option value="manojo">manojo</option><option value="litros">litros</option>
          </Select>
        </div>

        <Textarea label="¿Cómo se repartió? (opcional)" value={form.distribucion_descripcion} onChange={handleChange('distribucion_descripcion')}
                  placeholder="Ej: una lechuga para cada vecino del sector norte" />

        <label className="row" style={{ minHeight: 'var(--tap-min)' }}>
          <input type="checkbox" checked={form.es_distribuida} onChange={handleChange('es_distribuida')}
                 style={{ width: 24, height: 24 }} />
          Ya fue distribuida entre los vecinos
        </label>

        <label className="row" style={{ minHeight: 'var(--tap-min)' }}>
          <input type="checkbox" checked={form.marcar_cosechada} onChange={handleChange('marcar_cosechada')}
                 style={{ width: 24, height: 24 }} />
          Marcar la siembra como finalizada
        </label>

        {error && <p className="field__error" role="alert">{error}</p>}

        <Button type="submit" size="lg" fullWidth loading={enviando}>Registrar cosecha</Button>
      </form>
    </div>
  );
}
