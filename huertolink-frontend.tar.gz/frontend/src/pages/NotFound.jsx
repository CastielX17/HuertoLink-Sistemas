import { Link } from 'react-router-dom';
import Button from '../components/common/Button';

export default function NotFound() {
  return (
    <div className="page text-center" style={{ paddingTop: '20vh' }}>
      <span style={{ fontSize: '3rem' }} aria-hidden="true">🌿</span>
      <h1 style={{ marginTop: 'var(--space-4)' }}>Página no encontrada</h1>
      <p className="text-muted" style={{ margin: 'var(--space-3) 0 var(--space-6)' }}>
        Esta sección no existe o fue movida.
      </p>
      <Link to="/"><Button size="lg">Volver al inicio</Button></Link>
    </div>
  );
}
