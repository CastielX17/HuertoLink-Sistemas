/**
 * AuthContext — Gestión de sesión global.
 * Persiste el usuario y token en localStorage para que la sesión
 * sobreviva recargas de página (importante en huertos donde se
 * usa el celular con la app abierta todo el día).
 */
import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import * as authService from '../api/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('huertolink_user');
    const token  = localStorage.getItem('huertolink_token');
    if (stored && token) {
      try { setUsuario(JSON.parse(stored)); } catch { /* ignorar */ }
    }
    setCargando(false);
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await authService.login(email, password);
    const { token, usuario: u } = res.data;
    localStorage.setItem('huertolink_token', token);
    localStorage.setItem('huertolink_user', JSON.stringify(u));
    setUsuario(u);
    return u;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('huertolink_token');
    localStorage.removeItem('huertolink_user');
    setUsuario(null);
  }, []);

  const actualizarPerfil = useCallback((datos) => {
    setUsuario((prev) => {
      const actualizado = { ...prev, ...datos };
      localStorage.setItem('huertolink_user', JSON.stringify(actualizado));
      return actualizado;
    });
  }, []);

  const value = {
    usuario,
    cargando,
    autenticado: !!usuario,
    esCoordinadora: usuario?.id_rol === 1,
    login,
    logout,
    actualizarPerfil
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de <AuthProvider>');
  return ctx;
};
